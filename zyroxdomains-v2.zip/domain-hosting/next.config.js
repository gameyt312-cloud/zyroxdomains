/** @type {import('next').NextConfig} */
// No apex -> www redirect any more: zyroxdomains.in and www.zyroxdomains.in both serve the site.
// Add BOTH in Vercel -> Settings -> Domains and leave both on "no redirect".
const nextConfig = {};
module.exports = nextConfig;
