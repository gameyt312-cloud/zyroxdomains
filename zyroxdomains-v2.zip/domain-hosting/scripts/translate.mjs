// Adds a new language to lib/messages.js using Claude.  Usage (Node 22):
//   ANTHROPIC_API_KEY=... node scripts/translate.mjs it Italiano
// It prints a block to paste into MESSAGES and LANGS. Review it before shipping.
import { MESSAGES } from "../lib/messages.js";
const [code, name] = process.argv.slice(2);
if (!code || !process.env.ANTHROPIC_API_KEY) { console.error("Usage: ANTHROPIC_API_KEY=... node scripts/translate.mjs <code> <name>"); process.exit(1); }
const res = await fetch("https://api.anthropic.com/v1/messages", {
  method: "POST",
  headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
  body: JSON.stringify({
    model: "claude-sonnet-4-6", max_tokens: 4000,
    messages: [{ role: "user", content: `Translate the values of this JSON into ${name} for a domain-hosting website UI. Keep keys, {placeholders} and brand names unchanged. Return only JSON.\n\n${JSON.stringify(MESSAGES.en)}` }],
  }),
});
const data = await res.json();
const text = data.content?.[0]?.text?.replace(/```json|```/g, "").trim();
console.log(`// LANGS: { code: "${code}", name: "${name}" }\n${code}: ${text},`);
