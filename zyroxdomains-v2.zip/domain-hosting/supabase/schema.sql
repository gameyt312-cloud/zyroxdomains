-- Run once in Supabase: SQL Editor -> New query -> paste -> Run. Safe to re-run.
create extension if not exists pgcrypto;

create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  name text not null default '',
  password_hash text not null,
  credits int not null default 0 check (credits >= 0),
  plan text not null default 'free',
  plan_expires_at timestamptz,
  profile jsonb not null default '{}'::jsonb,   -- registrant details for domain purchases
  rc_customer_id text,
  rc_contact_id text,
  created_at timestamptz not null default now()
);

create table if not exists public.subdomains (
  id bigint generated always as identity primary key,
  name text not null unique check (name ~ '^[a-z0-9][a-z0-9-]{1,28}[a-z0-9]$'),
  target text not null,
  created_at timestamptz not null default now()
);
alter table public.subdomains add column if not exists owner_id uuid references public.users(id) on delete cascade;
alter table public.subdomains add column if not exists record_type text not null default 'CNAME';
alter table public.subdomains add column if not exists cf_record_id text;
alter table public.subdomains add column if not exists expires_at timestamptz not null default now() + interval '30 days';
create index if not exists subdomains_owner_idx on public.subdomains(owner_id);

create table if not exists public.domains (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.users(id) on delete cascade,
  domain text not null unique,
  years int not null default 1,
  registrar text not null,
  registrar_order_id text,
  nameservers text[] not null default '{}',
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  kind text not null check (kind in ('domain','plan')),
  item jsonb not null,
  amount int not null,                 -- paise
  currency text not null default 'INR',
  provider text not null,
  provider_order_id text,
  provider_payment_id text,
  status text not null default 'created', -- created -> fulfilling -> fulfilled | failed
  error text,
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
create index if not exists orders_user_idx on public.orders(user_id);
create unique index if not exists orders_provider_order_idx on public.orders(provider_order_id);

create table if not exists public.credit_ledger (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.users(id) on delete cascade,
  delta int not null,
  reason text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.ad_views (
  nonce text primary key,
  user_id uuid not null references public.users(id) on delete cascade,
  started_at timestamptz not null default now(),
  completed_at timestamptz
);
create index if not exists ad_views_user_idx on public.ad_views(user_id, started_at);

-- No policies: the public anon key can't touch anything. Only the server (service role) can.
alter table public.users enable row level security;
alter table public.subdomains enable row level security;
alter table public.domains enable row level security;
alter table public.orders enable row level security;
alter table public.credit_ledger enable row level security;
alter table public.ad_views enable row level security;

-- Atomic: finish one watched ad -> +1 credit. Returns new balance.
create or replace function public.grant_ad_credit(p_user uuid, p_nonce text, p_secs int, p_cap int)
returns int language plpgsql security definer as $$
declare v_today int; v_bal int;
begin
  select count(*) into v_today from ad_views
    where user_id = p_user and completed_at is not null and completed_at > now() - interval '24 hours';
  if v_today >= p_cap then raise exception 'DAILY_CAP'; end if;
  update ad_views set completed_at = now()
    where nonce = p_nonce and user_id = p_user and completed_at is null
      and started_at <= now() - make_interval(secs => p_secs);
  if not found then raise exception 'AD_INVALID'; end if;
  update users set credits = credits + 1 where id = p_user returning credits into v_bal;
  insert into credit_ledger(user_id, delta, reason) values (p_user, 1, 'ad');
  return v_bal;
end $$;

-- Atomic: renew a free subdomain. p_cost = 0 for paid plans. Returns new expiry.
create or replace function public.renew_subdomain(p_user uuid, p_sub bigint, p_cost int, p_days int)
returns timestamptz language plpgsql security definer as $$
declare v_exp timestamptz; v_new timestamptz;
begin
  select expires_at into v_exp from subdomains where id = p_sub and owner_id = p_user for update;
  if not found then raise exception 'NOT_FOUND'; end if;
  if v_exp > now() + interval '7 days' then raise exception 'TOO_EARLY'; end if;
  if p_cost > 0 then
    update users set credits = credits - p_cost where id = p_user and credits >= p_cost;
    if not found then raise exception 'NO_CREDITS'; end if;
    insert into credit_ledger(user_id, delta, reason) values (p_user, -p_cost, 'renew:' || p_sub);
  end if;
  v_new := greatest(v_exp, now()) + make_interval(days => p_days);
  update subdomains set expires_at = v_new where id = p_sub;
  return v_new;
end $$;

revoke all on function public.grant_ad_credit(uuid, text, int, int) from public, anon, authenticated;
revoke all on function public.renew_subdomain(uuid, bigint, int, int) from public, anon, authenticated;

grant execute on function public.grant_ad_credit(uuid, text, int, int) to service_role;
grant execute on function public.renew_subdomain(uuid, bigint, int, int) to service_role;

-- v2: multi-currency orders and DNS zones for bought domains
alter table public.orders add column if not exists charge_amount int;
alter table public.domains add column if not exists zone_id text;

-- v3: automatic setup, free landing page, URL forwarding, transfer lock
alter table public.domains add column if not exists setup_error text;
alter table public.domains add column if not exists forward_to text;
alter table public.domains add column if not exists forward_type int not null default 302;
alter table public.domains add column if not exists site jsonb not null default '{}'::jsonb;
alter table public.domains add column if not exists locked boolean not null default true;
alter table public.subdomains add column if not exists forward_to text;
alter table public.subdomains add column if not exists forward_type int not null default 302;
alter table public.subdomains add column if not exists site jsonb not null default '{}'::jsonb;
