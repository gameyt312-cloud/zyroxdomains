# ZyroxDomains (www.zyroxdomains.in)

Domains, free 30-day subdomains renewed with ad credits, paid plans, 26 currencies, 10 languages.

## 1. Getting zyroxdomains.in and www.zyroxdomains.in live (www is optional)
Both addresses serve the same site; there is no redirect between them. This is a hosting/DNS step I cannot do from code:
1. Put this folder in GitHub, import it in Vercel, add the env vars (section 2), deploy. Open the `*.vercel.app` URL first. If it loads, the code is fine.
2. Vercel -> Settings -> Domains: add `zyroxdomains.in` and `www.zyroxdomains.in`. Leave BOTH with no redirect.
3. At your DNS provider: `A` `@` -> `76.76.21.21`, `CNAME` `www` -> the target Vercel shows (usually `cname.vercel-dns.com`). In Cloudflare use **DNS only** (grey cloud). Delete old A/AAAA for `@`.
4. Wait up to an hour, then open `/api/health`. It lists anything still unconfigured.

## 2. Setup
1. **Supabase:** run `supabase/schema.sql` (safe to re-run). Your data lives in Supabase's cloud database.
2. **Cloudflare:** add `zyroxdomains.in`. Token with Zone:DNS:Edit and Zone:Zone:Edit. Fill `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ZONE_ID`, `CLOUDFLARE_ACCOUNT_ID`.
3. **Registrar:** ResellerClub. Sandbox first (`RC_BASE_URL=https://test.httpapi.com`), live later (`https://httpapi.com`). Sandbox domains are not real registrations.
4. **Payments:** Razorpay for INR, Stripe for everything else (add both webhooks: `/api/webhooks/razorpay`, `/api/webhooks/stripe`).
5. **Vercel:** all variables from `.env.example`, including `VERCEL_API_TOKEN` and `VERCEL_PROJECT_ID` (needed for automatic HTTPS on customer domains). Run `supabase/schema.sql` again (it now has v3 columns). Sign up on the site with zyroxop443@gmail.com to get `/admin`.

## 3. What happens when someone buys a domain (fully automatic)
Payment verified -> domain registered at ResellerClub -> DNS zone created in your Cloudflare -> nameservers switched to it -> **default records created (A @ and CNAME www)** -> **domain and www attached to your Vercel project (HTTPS certificate is issued by Vercel)** -> visitors see a free landing page. The buyer does nothing. If registration fails the payment is refunded. If only the auto-setup step fails, the domain is kept and the dashboard shows a "Retry setup" button.
Honest timing: the domain can't resolve until the new nameservers propagate (usually minutes, sometimes a few hours). The dashboard shows Live / Setting up and has a "Check again" button.
Free domains are `name.zyroxdomains.in` subdomains. They also set up automatically (default = free page, no target needed).

### Features per domain (Dashboard -> Domains / Subdomains -> Manage)
Live status, free landing page (title, text, button, colour), URL forwarding (301/302), one-click DNS setups (ZyroxDomains page, GitHub Pages, Google Workspace email), full DNS record editor, custom nameservers, transfer lock and transfer auth code. Customer pages never show ads or our navigation (Google doesn't allow ads on parked pages).
Not built yet: domain renewal checkout / auto-renew, domain transfer-in, WHOIS privacy purchase, email hosting, website builder. Vercel limits how many domains one project can hold on your plan; at large scale move to Cloudflare for SaaS.

## 4. Money
- **Sales:** Razorpay and Stripe pay out to the bank account on those accounts, not to a Gmail address. Register both with zyroxop443@gmail.com.
- **Ads:** Google pays AdSense / Ad Manager earnings to the bank account in your Google payments profile, after you pass its payout threshold. Not to Google Pay. Steps: sign up for AdSense with zyroxop443@gmail.com, get the site approved, set `ADSENSE_PUB_ID` (served at `/ads.txt`), then ask Google to enable rewarded ads in Ad Manager and set `NEXT_PUBLIC_GPT_REWARDED_UNIT` and `NEXT_PUBLIC_AD_SECONDS=5`. Plain AdSense ads must not be used to reward people; rewarded ad units are the allowed route. Google can't verify web rewards on the server, so credit farming is limited only by the daily cap and one-ad-at-a-time rule.
- Your domain profit = selling price (`lib/config.js`) minus ResellerClub's wholesale price, which you pay from your reseller balance.

## 5. Currencies and languages
26 currencies (rates refresh every 6 hours with a 2% margin). 10 languages cover the main screens (nav, home, search, plans, login, checkout, dashboard tabs); other text falls back to English. Add a language: `ANTHROPIC_API_KEY=... node scripts/translate.mjs it Italiano`, then paste the output into `lib/messages.js`.

## Known limits
Registrar and payment calls were written without internet access and haven't been run: test one sandbox purchase and one Stripe/Razorpay test payment before going live. Not included: email verification, password reset, auto-renewal of domains, WHOIS privacy, server hosting.
