import { NextResponse } from "next/server";

// Our own site answers on zyroxdomains.in AND www.zyroxdomains.in (www is optional, no redirect between them).
// Any OTHER hostname (a customer's domain or name.zyroxdomains.in) is served by /site/[host].
const ROOT = (process.env.NEXT_PUBLIC_ROOT_DOMAIN || "zyroxdomains.in").toLowerCase();

export function middleware(req) {
  const host = (req.headers.get("host") || "").toLowerCase().split(":")[0];
  if (!host || host === ROOT || host === `www.${ROOT}` || host === "localhost" || host === "127.0.0.1" || host.endsWith(".vercel.app")) {
    return NextResponse.next();
  }
  const url = req.nextUrl.clone();
  url.pathname = `/site/${host}`;
  url.search = "";
  return NextResponse.rewrite(url);
}

export const config = { matcher: ["/((?!_next/|favicon.ico|robots.txt).*)"] };
