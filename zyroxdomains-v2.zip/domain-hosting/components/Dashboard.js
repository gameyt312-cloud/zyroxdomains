"use client";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { api, daysLeft } from "@/lib/client";
import { formatMinor } from "@/lib/currency";
import { usePrefs } from "./Prefs";
import { PLANS, RENEW_CREDITS } from "@/lib/config";
import EarnCredits from "./EarnCredits";
import DomainManage from "./DomainManage";

const TABS = ["overview", "subdomains", "domains", "credits", "billing"];

export default function Dashboard() {
  const { t } = usePrefs();
  const sp = useSearchParams();
  const router = useRouter();
  const [tab, setTab] = useState(sp.get("tab") || "overview");
  const [me, setMe] = useState(null);
  const refresh = useCallback(() => api("/api/auth/me").then((r) => {
    if (!r.data.user) router.replace("/login?next=/dashboard"); else setMe(r.data.user);
  }), [router]);
  useEffect(() => { refresh(); }, [refresh]);
  if (!me) return <div className="wrap page"><p className="note">Loading...</p></div>;
  return (
    <div className="wrap page">
      <h1>Hi{me.name ? `, ${me.name.split(" ")[0]}` : ""}</h1>
      <p className="lead">{me.email}</p>
      {sp.get("paid") && <p className="msg ok" style={{ marginBottom: 16 }}>Payment received. Thank you!</p>}
      <div className="tabs" role="tablist">{TABS.map((k) => <button key={k} role="tab" className={tab === k ? "on" : ""} onClick={() => setTab(k)}>{t(`dash.${k}`)}</button>)}</div>
      {tab === "overview" && <Overview me={me} go={setTab} />}
      {tab === "subdomains" && <Subdomains me={me} refresh={refresh} />}
      {tab === "domains" && <Domains />}
      {tab === "credits" && <EarnCredits credits={me.credits} onCredits={(c) => setMe({ ...me, credits: c })} />}
      {tab === "billing" && <Billing />}
    </div>
  );
}

function Overview({ me, go }) {
  const plan = PLANS[me.plan];
  return (
    <>
      <div className="stats">
        <div className="card stat"><b>{plan.name}</b><span>Current plan{me.plan !== "free" && me.planExpiresAt ? `, until ${new Date(me.planExpiresAt).toLocaleDateString("en-IN")}` : ""}</span></div>
        <div className="card stat"><b>{me.credits}</b><span>Credits ({RENEW_CREDITS} renews a free subdomain)</span></div>
        <div className="card stat"><b>{plan.subdomains}</b><span>Subdomains allowed</span></div>
      </div>
      <div className="card">
        <h2 style={{ fontSize: "1.2rem", marginBottom: 10 }}>What next?</h2>
        <div className="row" style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button className="btn" onClick={() => go("subdomains")}>Claim a free subdomain</button>
          <Link className="btn ghost" href="/domains">Buy a domain</Link>
          {me.plan === "free" && <Link className="btn gold" href="/pricing">Skip the ads with a plan</Link>}
        </div>
      </div>
    </>
  );
}

function Subdomains({ me, refresh }) {
  const [data, setData] = useState(null);
  const [f, setF] = useState({ name: "", type: "PLATFORM", target: "" });
  const [open, setOpen] = useState(null);
  const [msg, setMsg] = useState(null);
  const [edit, setEdit] = useState(null);
  const load = useCallback(() => api("/api/subdomains").then((r) => setData(r.data)), []);
  useEffect(() => { load(); }, [load]);

  async function claim(e) {
    e.preventDefault(); setMsg(null);
    const r = await api("/api/subdomains", { method: "POST", body: f });
    if (!r.ok) return setMsg({ t: "err", m: r.data.error });
    setMsg({ t: "ok", m: `${r.data.hostname} is yours.${r.data.dnsCreated ? " It goes live automatically in a few minutes. Open Manage to edit your page." : " Saved, but DNS isn't connected on this server yet."}` });
    setF({ name: "", type: "PLATFORM", target: "" }); load();
  }
  async function act(id, method, path = "", body) {
    setMsg(null);
    const r = await api(`/api/subdomains/${id}${path}`, { method, body });
    if (!r.ok) setMsg({ t: "err", m: r.data.error }); else setMsg({ t: "ok", m: "Done." });
    setEdit(null); load(); refresh();
  }
  if (!data) return <p className="note">Loading...</p>;
  const full = data.items.length >= data.limit;
  return (
    <>
      <div className="card">
        <h2 style={{ fontSize: "1.2rem", marginBottom: 4 }}>Claim a free subdomain</h2>
        <p className="note" style={{ marginTop: 0 }}>{data.items.length} of {data.limit} used on your {PLANS[data.plan].name} plan. Valid for {PLANS[data.plan].days} days.</p>
        <form onSubmit={claim}>
          <div className="grid2">
            <div className="field"><label htmlFor="sn">Name</label><input id="sn" required value={f.name} placeholder="yourname" onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
            <div className="field"><label htmlFor="st">Record type</label><select id="st" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="PLATFORM">Free ZyroxDomains page (no setup)</option><option value="CNAME">CNAME (to my own host)</option><option value="A">A (to my own IP)</option></select></div>
          </div>
          {f.type !== "PLATFORM" && <div className="field"><label htmlFor="sg">Points to</label><input id="sg" required value={f.target} placeholder={f.type === "A" ? "76.76.21.21" : "my-site.vercel.app"} onChange={(e) => setF({ ...f, target: e.target.value })} /></div>}
          <p className="note" style={{ marginTop: 0 }}>Your address will be <code>{f.name || "yourname"}.{data.root}</code></p>
          <button className="btn" disabled={full}>{full ? "Limit reached" : "Claim subdomain"}</button>
          {full && <> <Link href="/pricing">Upgrade for more</Link></>}
        </form>
        {msg && <p className={`msg ${msg.t}`}>{msg.m}</p>}
      </div>
      <div className="card">
        {data.items.length === 0 && <p className="note">No subdomains yet. Claim your first one above.</p>}
        {data.items.map((s) => {
          const d = daysLeft(s.expires_at);
          const expired = d <= 0;
          return (
            <div className="item" key={s.id}>
              <div className="grow">
                <div className="host">{s.name}.{data.root}</div>
                <div className="meta">{s.record_type} → {s.target}</div>
                {edit?.id === s.id && (
                  <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                    <select style={{ width: 110 }} value={edit.type} onChange={(e) => setEdit({ ...edit, type: e.target.value })}><option>CNAME</option><option>A</option></select>
                    <input style={{ flex: 1, minWidth: 160 }} value={edit.target} onChange={(e) => setEdit({ ...edit, target: e.target.value })} aria-label="New target" />
                    <button className="btn sm" onClick={() => act(s.id, "PATCH", "", { type: edit.type, target: edit.target })}>Save</button>
                  </div>
                )}
                {open === s.id && <DomainManage base={`/api/subdomains/${s.id}`} isDomain={false} onChanged={load} />}
              </div>
              <span className={`badge ${expired ? "bad" : d <= 7 ? "warn" : ""}`}>{expired ? "Expired" : `${d} days left`}</span>
              {!expired && <button className="btn sm" onClick={() => setOpen(open === s.id ? null : s.id)}>Manage</button>}
              {!expired && <button className="btn ghost sm" onClick={() => setEdit({ id: s.id, type: s.record_type, target: s.target })}>Edit</button>}
              {d <= 7 && <button className="btn gold sm" onClick={() => act(s.id, "POST", "/renew")}>{data.freeRenew ? "Renew free" : `Renew (${RENEW_CREDITS} credits)`}</button>}
              <button className="btn danger sm" onClick={() => confirm(`Delete ${s.name}.${data.root}?`) && act(s.id, "DELETE")}>Delete</button>
            </div>
          );
        })}
        {!data.freeRenew && data.items.length > 0 && <p className="note">Not enough credits? Open the <b>Earn credits</b> tab. Renewal opens 7 days before expiry.</p>}
        {!data.dns && <p className="note">DNS isn't connected on this server, so subdomains are saved but won't resolve yet.</p>}
      </div>
    </>
  );
}

function Domains() {
  const [items, setItems] = useState(null);
  const load = useCallback(() => api("/api/my-domains").then((r) => setItems(r.data.items || [])), []);
  useEffect(() => { load(); }, [load]);
  if (!items) return <p className="note">Loading...</p>;
  return (
    <>
      {items.length === 0 && <div className="card"><p className="note" style={{ margin: 0 }}>You haven't bought a domain yet. <Link href="/domains">Search for one</Link>.</p></div>}
      {items.map((d) => <DomainCard key={d.id} d={d} reload={load} />)}
    </>
  );
}

function DomainCard({ d, reload }) {
  const [recs, setRecs] = useState(null);
  const [f, setF] = useState({ type: "A", name: "@", content: "", priority: 10 });
  const [ns, setNs] = useState(d.nameservers.join("\n"));
  const [msg, setMsg] = useState(null);
  const [manage, setManage] = useState(true);
  const loadRecs = useCallback(() => d.hasDns && api(`/api/my-domains/${d.id}/dns`).then((r) => r.ok ? setRecs(r.data.records) : setMsg({ t: "err", m: r.data.error })), [d.id, d.hasDns]);
  useEffect(() => { loadRecs(); }, [loadRecs]);
  async function add(e) {
    e.preventDefault(); setMsg(null);
    const r = await api(`/api/my-domains/${d.id}/dns`, { method: "POST", body: f });
    if (!r.ok) return setMsg({ t: "err", m: r.data.error });
    setF({ ...f, content: "" }); setMsg({ t: "ok", m: "Record added. It can take a few minutes to work." }); loadRecs();
  }
  async function del(id) { const r = await api(`/api/my-domains/${d.id}/dns?rid=${id}`, { method: "DELETE" }); if (!r.ok) setMsg({ t: "err", m: r.data.error }); loadRecs(); }
  async function saveNs() {
    const r = await api("/api/my-domains", { method: "PATCH", body: { id: d.id, nameservers: ns.split(/[\s,]+/).filter(Boolean) } });
    setMsg(r.ok ? { t: "ok", m: "Nameservers updated. Changes can take up to 24 hours." } : { t: "err", m: r.data.error }); reload();
  }
  return (
    <div className="card">
      <div className="host" style={{ fontSize: "1.2rem" }}>{d.domain}</div>
      <div className="meta">Expires {d.expires_at ? new Date(d.expires_at).toLocaleDateString() : "-"}</div>
      {d.hasDns && <button className="btn ghost sm" style={{ marginTop: 8 }} onClick={() => setManage(!manage)}>{manage ? "Hide website settings" : "Website settings"}</button>}
      {d.hasDns && manage && <DomainManage base={`/api/my-domains/${d.id}`} isDomain onChanged={loadRecs} />}
      {d.hasDns ? (
        <>
          <h3 style={{ fontSize: "1rem", margin: "16px 0 4px" }}>Advanced DNS records</h3>
          <p className="note" style={{ marginTop: 0 }}>Nameservers: {d.nameservers.join(", ")}</p>
          <form onSubmit={add} className="grid2" style={{ gridTemplateColumns: "90px 1fr 2fr auto", alignItems: "end", gap: 8 }}>
            <div><label>Type</label><select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}>{["A", "AAAA", "CNAME", "TXT", "MX"].map((x) => <option key={x}>{x}</option>)}</select></div>
            <div><label>Name</label><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="@ or www" /></div>
            <div><label>Value</label><input required value={f.content} onChange={(e) => setF({ ...f, content: e.target.value })} placeholder={f.type === "A" ? "76.76.21.21" : f.type === "CNAME" ? "cname.vercel-dns.com" : ""} /></div>
            <button className="btn sm">Add</button>
          </form>
          <div className="scroll" style={{ marginTop: 14 }}>
            <table><thead><tr><th>Type</th><th>Name</th><th>Value</th><th /></tr></thead><tbody>
              {(recs || []).map((r) => <tr key={r.id}><td>{r.type}</td><td>{r.name}</td><td style={{ wordBreak: "break-all" }}>{r.priority != null && r.type === "MX" ? `${r.priority} ` : ""}{r.content}</td><td><button className="btn danger sm" onClick={() => confirm("Delete this record?") && del(r.id)}>Delete</button></td></tr>)}
            </tbody></table>
          </div>
        </>
      ) : (
        <>
          <label htmlFor={`ns${d.id}`} style={{ marginTop: 12 }}>Nameservers (one per line)</label>
          <textarea id={`ns${d.id}`} rows={3} style={{ width: "100%", border: "1.5px solid var(--line)", borderRadius: 10, padding: 10, font: "inherit" }} value={ns} onChange={(e) => setNs(e.target.value)} />
          <button className="btn sm" style={{ marginTop: 8 }} onClick={saveNs}>Save nameservers</button>
        </>
      )}
      {msg && <p className={`msg ${msg.t}`}>{msg.m}</p>}
    </div>
  );
}

function Billing() {
  const [items, setItems] = useState(null);
  useEffect(() => { api("/api/orders").then((r) => setItems(r.data.items || [])); }, []);
  if (!items) return <p className="note">Loading...</p>;
  return (
    <div className="card scroll">
      {items.length === 0 ? <p className="note">No orders yet.</p> : (
        <table><thead><tr><th>Date</th><th>Item</th><th>Amount</th><th>Status</th></tr></thead><tbody>
          {items.map((o) => <tr key={o.id}><td>{new Date(o.created_at).toLocaleDateString("en-IN")}</td><td>{o.item}</td><td>{formatMinor(o.charge_amount ?? o.amount, o.currency || "INR")}</td><td>{o.status === "fulfilled" ? "Paid" : o.status === "failed" ? `Failed: ${o.error || ""}` : "Pending"}</td></tr>)}
        </tbody></table>
      )}
    </div>
  );
}
