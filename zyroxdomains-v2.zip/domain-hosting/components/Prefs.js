"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { LANGS, MESSAGES } from "@/lib/messages";
import { CURRENCIES, REGION_CUR, formatMinor, toMinor } from "@/lib/currency";

const Ctx = createContext(null);
export const usePrefs = () => useContext(Ctx);

export default function Prefs({ children }) {
  const [lang, setLangS] = useState("en");
  const [cur, setCurS] = useState("USD");
  const [rates, setRates] = useState(null);

  useEffect(() => {
    let l = localStorage.getItem("zd_lang"), c = localStorage.getItem("zd_cur");
    const nav = navigator.language || "en";
    if (!l) { const p = nav.slice(0, 2).toLowerCase(); l = MESSAGES[p] ? p : "en"; }
    if (!c) { const region = (nav.split("-")[1] || "").toUpperCase(); c = REGION_CUR[region] || (nav.startsWith("hi") ? "INR" : "USD"); }
    setLangS(l); setCurS(c);
    fetch("/api/rates").then((r) => r.json()).then((d) => setRates(d.rates)).catch(() => {});
  }, []);
  useEffect(() => {
    const dir = LANGS.find((x) => x.code === lang)?.dir || "ltr";
    document.documentElement.lang = lang; document.documentElement.dir = dir;
  }, [lang]);

  const setLang = (l) => { setLangS(l); localStorage.setItem("zd_lang", l); };
  const setCur = (c) => { setCurS(c); localStorage.setItem("zd_cur", c); };
  const t = useCallback((key, vars) => {
    let s = MESSAGES[lang]?.[key] ?? MESSAGES.en[key] ?? key;
    if (vars) for (const [k, v] of Object.entries(vars)) s = s.replace(`{${k}}`, v);
    return s;
  }, [lang]);
  // INR paise -> text in the chosen currency (shows INR until rates arrive)
  const fmt = useCallback((paise) => {
    if (cur === "INR" || !rates?.[cur]) return formatMinor(paise, "INR", lang);
    return formatMinor(toMinor(paise, cur, rates[cur]), cur, lang);
  }, [cur, rates, lang]);
  const shown = !rates?.[cur] ? "INR" : cur;

  const value = useMemo(() => ({ lang, setLang, cur: shown, setCur, t, fmt, currencies: Object.keys(CURRENCIES) }), [lang, shown, t, fmt]); // eslint-disable-line
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
