"use client";
import { useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { api } from "@/lib/client";
import { usePrefs } from "./Prefs";
import { PLANS } from "@/lib/config";

const FIELDS = [
  ["name", "Full name", "name"], ["phone", "Phone (digits only, no + or country code)", "tel"], ["address", "Street address", "street-address"],
  ["city", "City", "address-level2"], ["state", "State / region", "address-level1"], ["zip", "Postal / PIN code", "postal-code"], ["country", "Country code (IN, US, GB...)", "country"],
];

function loadRazorpay() {
  return new Promise((ok, fail) => {
    if (window.Razorpay) return ok();
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = ok; s.onerror = () => fail(new Error("Could not load the payment window."));
    document.body.appendChild(s);
  });
}

export default function Checkout() {
  const sp = useSearchParams();
  const router = useRouter();
  const { t, fmt, cur } = usePrefs();
  const domain = sp.get("domain");
  const planKey = sp.get("plan");
  const period = sp.get("period") === "year" ? "year" : "month";
  const [user, setUser] = useState(undefined);
  const [years, setYears] = useState(1);
  const [unit, setUnit] = useState(null);
  const [p, setP] = useState({});
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [mock, setMock] = useState(null);

  useEffect(() => {
    api("/api/auth/me").then((r) => {
      const u = r.data.user;
      if (!u) return router.replace(`/login?next=${encodeURIComponent(location.pathname + location.search)}`);
      setUser(u); setP((x) => ({ name: u.name, ...u.profile, ...x }));
    });
  }, [router]);
  useEffect(() => {
    if (!domain) return;
    api(`/api/domains/check?q=${encodeURIComponent(domain)}`).then((r) => {
      const hit = r.data.results?.find((x) => x.domain === domain);
      setUnit(hit && hit.status === "available" ? hit.price : -1);
    });
  }, [domain]);

  if (!user) return <div className="wrap page"><p className="note">Loading...</p></div>;
  const plan = PLANS[planKey];
  if (!domain && !(plan && planKey !== "free")) return <div className="wrap page"><h1>Nothing to buy</h1><p className="lead">Pick a domain or a plan first.</p></div>;

  const total = domain ? (unit > 0 ? unit * years : null) : plan[period];
  const title = domain ? domain : `${plan.name} plan, ${period === "year" ? "1 year" : "1 month"}`;

  async function finish(orderId, paymentId, signature) {
    const v = await api("/api/checkout/verify", { method: "POST", body: { orderId, paymentId, signature } });
    setBusy(false); setMock(null);
    if (!v.ok) return setErr(v.data.error || "Payment could not be confirmed. If money was taken, contact support.");
    router.push(domain ? "/dashboard?tab=domains&paid=1" : "/dashboard?paid=1");
  }

  async function pay(e) {
    e.preventDefault(); setBusy(true); setErr("");
    const r = await api("/api/checkout", { method: "POST", body: { currency: cur, ...(domain ? { kind: "domain", domain, years, profile: p } : { kind: "plan", plan: planKey, period }) } });
    if (!r.ok) { setBusy(false); return setErr(r.data.error || "Could not start checkout."); }
    const o = r.data;
    if (o.provider === "mock") { setMock(o); return; }
    if (o.provider === "stripe") { window.location.href = o.url; return; }
    try {
      await loadRazorpay();
      new window.Razorpay({
        key: o.keyId, amount: o.chargeAmount, currency: o.currency, name: "ZyroxDomains", description: o.description, order_id: o.providerOrderId,
        prefill: { email: o.email, name: o.name }, theme: { color: "#1b1858" },
        handler: (resp) => finish(o.orderId, resp.razorpay_payment_id, resp.razorpay_signature),
        modal: { ondismiss: () => setBusy(false) },
      }).open();
    } catch (x) { setBusy(false); setErr(x.message); }
  }

  return (
    <div className="narrow" style={{ maxWidth: 620 }}>
      <h1 style={{ fontSize: "2rem", marginBottom: 6 }}>{t("checkout.title")}</h1>
      <p className="lead" style={{ marginBottom: 18 }}>{title}</p>
      {domain && unit === -1 && <p className="msg err">This domain is no longer available. <a href="/domains">Search again</a></p>}
      <form className="card" onSubmit={pay}>
        {domain && (
          <>
            <div className="field"><label htmlFor="y">{t("checkout.years")}</label>
              <select id="y" value={years} onChange={(e) => setYears(+e.target.value)}>{[1, 2, 3, 5].map((y) => <option key={y} value={y}>{y} year{y > 1 ? "s" : ""}</option>)}</select></div>
            <p className="note" style={{ marginTop: 0 }}>Registrars need these contact details to register a domain in your name.</p>
            <div className="grid2">
              {FIELDS.map(([k, l, ac]) => (
                <div className="field" key={k}><label htmlFor={k}>{l}</label><input id={k} required autoComplete={ac} value={p[k] || ""} onChange={(e) => setP({ ...p, [k]: e.target.value })} /></div>
              ))}
            </div>
          </>
        )}
        <p style={{ fontSize: "1.2rem", fontWeight: 700, margin: "6px 0 16px" }}>{t("checkout.total")}: {total ? fmt(total) : "..."}</p>
        <button className="btn gold" style={{ width: "100%" }} disabled={busy || !total}>{busy ? t("auth.wait") : `${t("checkout.pay")} ${total ? fmt(total) : ""}`}</button>
        {err && <p className="msg err">{err}</p>}
      </form>
      {mock && (
        <div className="card">
          <b>Test mode</b>
          <p className="note">No real payment window is shown because the server is in test payment mode.</p>
          <button className="btn" onClick={() => finish(mock.orderId, `pay_mock_${Date.now()}`, "mock")}>Complete test payment</button>
        </div>
      )}
    </div>
  );
}
