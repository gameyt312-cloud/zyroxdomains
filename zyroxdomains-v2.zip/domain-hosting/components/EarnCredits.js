"use client";
import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/client";
import AdSlot from "./AdSlot";

const GPT_UNIT = process.env.NEXT_PUBLIC_GPT_REWARDED_UNIT;

// Google Ad Manager rewarded ad for web. Resolves only when Google grants the reward.
function playRewarded() {
  return new Promise((resolve, reject) => {
    window.googletag = window.googletag || { cmd: [] };
    const g = window.googletag;
    const timeout = setTimeout(() => finish(new Error("No ad available right now. Try again soon.")), 15000);
    let slot, granted = false, shown = false;
    const on = { rewardedSlotReady: (e) => { if (e.slot === slot) { shown = true; clearTimeout(timeout); e.makeRewardedVisible(); } },
      rewardedSlotGranted: (e) => { if (e.slot === slot) granted = true; },
      rewardedSlotClosed: (e) => { if (e.slot === slot) finish(granted ? null : new Error("Watch the full ad to earn a credit.")); },
      slotRenderEnded: (e) => { if (e.slot === slot && e.isEmpty && !shown) finish(new Error("No ad available right now. Try again soon.")); } };
    function finish(err) {
      clearTimeout(timeout);
      try { for (const [k, f] of Object.entries(on)) g.pubads().removeEventListener(k, f); g.destroySlots([slot]); } catch {}
      err ? reject(err) : resolve();
    }
    g.cmd.push(() => {
      slot = g.defineOutOfPageSlot(GPT_UNIT, g.enums.OutOfPageFormat.REWARDED);
      if (!slot) return finish(new Error("Rewarded ads aren't supported on this device or browser."));
      slot.addService(g.pubads());
      for (const [k, f] of Object.entries(on)) g.pubads().addEventListener(k, f);
      g.enableServices(); g.display(slot);
    });
  });
}

export default function EarnCredits({ credits, onCredits }) {
  const [run, setRun] = useState(null); // { nonce, seconds, left }
  const [msg, setMsg] = useState(null);
  const done = useRef(false);

  useEffect(() => {
    if (!run) return;
    const t = setInterval(() => {
      if (document.visibilityState !== "visible") return; // timer pauses while the tab is hidden
      setRun((r) => (r ? { ...r, left: r.left - 1 } : r));
    }, 1000);
    return () => clearInterval(t);
  }, [run?.nonce]);

  useEffect(() => {
    if (run && run.left <= 0 && !done.current) {
      done.current = true;
      api("/api/ads/complete", { method: "POST", body: { nonce: run.nonce } }).then((r) => {
        setRun(null);
        if (r.ok) { onCredits(r.data.credits); setMsg({ t: "ok", m: "+1 credit earned." }); }
        else setMsg({ t: "err", m: r.data.error });
      });
    }
  }, [run, onCredits]);

  async function start() {
    setMsg(null); done.current = false;
    const r = await api("/api/ads/start", { method: "POST" });
    if (!r.ok) return setMsg({ t: "err", m: r.data.error });
    if (GPT_UNIT) {
      try { await playRewarded(); } catch (e) { return setMsg({ t: "err", m: e.message }); }
      const c = await api("/api/ads/complete", { method: "POST", body: { nonce: r.data.nonce } });
      return c.ok ? (onCredits(c.data.credits), setMsg({ t: "ok", m: "+1 credit earned." })) : setMsg({ t: "err", m: c.data.error });
    }
    setRun({ nonce: r.data.nonce, seconds: r.data.seconds, left: r.data.seconds });
  }

  return (
    <div className="card">
      <h2 style={{ fontSize: "1.3rem", marginBottom: 6 }}>Earn credits</h2>
      <p className="note" style={{ marginTop: 0 }}>Watch one ad to earn 1 credit. Renewing a free subdomain costs 10 credits. You have <b>{credits}</b>.</p>
      <div className="adbox">
        {run ? <div style={{ width: "100%" }}><AdSlot /><div className="bar" style={{ marginTop: 14 }}><i style={{ width: `${((run.seconds - run.left) / run.seconds) * 100}%` }} /></div><p className="note">{Math.max(run.left, 0)}s left. Keep this tab open.</p></div>
          : <p className="note">Press the button to start the next ad.</p>}
      </div>
      <button className="btn gold" onClick={start} disabled={!!run}>{run ? "Watching..." : "Watch an ad"}</button>
      {msg && <p className={`msg ${msg.t}`}>{msg.m}</p>}
    </div>
  );
}
