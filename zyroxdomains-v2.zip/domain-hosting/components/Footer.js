import Link from "next/link";
export default function Footer() {
  return (
    <footer className="foot">
      <div className="wrap">
        <div><b style={{ color: "#fff" }}>ZyroxDomains</b><br />zyroxdomains.in<br />Support: zyroxop443@gmail.com</div>
        <div><Link href="/domains">Search domains</Link><Link href="/pricing">Plans</Link><Link href="/dashboard">Dashboard</Link></div>
        <div><Link href="/legal/terms">Terms</Link><Link href="/legal/privacy">Privacy</Link><Link href="/legal/refunds">Refunds</Link><Link href="/legal/contact">Contact</Link></div>
      </div>
    </footer>
  );
}
