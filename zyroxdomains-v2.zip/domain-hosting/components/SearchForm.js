"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { usePrefs } from "./Prefs";
export default function SearchForm({ initial = "" }) {
  const [q, setQ] = useState(initial);
  const router = useRouter();
  const { t } = usePrefs();
  return (
    <form className="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) router.push(`/domains?q=${encodeURIComponent(q.trim())}`); }}>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search.placeholder")} aria-label="Domain name" autoComplete="off" />
      <button className="btn gold">{t("search.button")}</button>
    </form>
  );
}
