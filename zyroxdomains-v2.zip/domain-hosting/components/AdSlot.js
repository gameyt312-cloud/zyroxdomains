"use client";
import { useEffect } from "react";

// Shows a real ad when NEXT_PUBLIC_ADSENSE_CLIENT and NEXT_PUBLIC_ADSENSE_SLOT are set,
// otherwise a placeholder. Swap this component's contents for your rewarded-ad network's SDK.
export default function AdSlot() {
  const client = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;
  const slot = process.env.NEXT_PUBLIC_ADSENSE_SLOT;
  useEffect(() => { if (client && slot) try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch {} }, [client, slot]);
  if (client && slot) return <ins className="adsbygoogle" style={{ display: "block", minHeight: 180 }} data-ad-client={client} data-ad-slot={slot} data-ad-format="auto" data-full-width-responsive="true" />;
  return <div><b>Ad space</b><p className="note">Connect your ad network in <code>components/AdSlot.js</code>.<br />Until then this placeholder runs the same timer.</p></div>;
}
