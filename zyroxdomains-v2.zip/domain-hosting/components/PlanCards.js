"use client";
import Link from "next/link";
import { useState } from "react";
import { PLANS } from "@/lib/config";
import { usePrefs } from "./Prefs";

export default function PlanCards() {
  const [period, setPeriod] = useState("month");
  const { t, fmt } = usePrefs();
  return (
    <>
      <div className="toggle" role="group" aria-label="Billing period">
        <button className={period === "month" ? "on" : ""} onClick={() => setPeriod("month")}>{t("plans.monthly")}</button>
        <button className={period === "year" ? "on" : ""} onClick={() => setPeriod("year")}>{t("plans.yearly")}</button>
      </div>
      <div className="plans">
        {Object.entries(PLANS).map(([key, p]) => (
          <div key={key} className={`card plan ${key === "premium" ? "hot" : ""}`}>
            {key === "premium" && <span className="tag">{t("plans.popular")}</span>}
            <h3>{p.name}</h3>
            <div className="price">{p[period] ? fmt(p[period]) : fmt(0)}<small> {p[period] ? t(period === "year" ? "plans.year" : "plans.month") : t("plans.forever")}</small></div>
            <ul>{p.perks.map((x) => <li key={x}>{x}</li>)}</ul>
            {key === "free"
              ? <Link href="/signup" className="btn ghost">{t("plans.start")}</Link>
              : <Link href={`/checkout?plan=${key}&period=${period}`} className={`btn ${key === "premium" ? "gold" : ""}`}>{t("plans.choose")} {p.name}</Link>}
          </div>
        ))}
      </div>
    </>
  );
}
