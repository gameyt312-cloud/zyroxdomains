"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { api } from "@/lib/client";

export default function CheckoutSuccess() {
  const order = useSearchParams().get("order");
  const [s, setS] = useState({ state: "wait", msg: "" });
  useEffect(() => {
    let tries = 0;
    const go = async () => {
      const r = await api("/api/checkout/verify", { method: "POST", body: { orderId: order } });
      if (r.ok) return setS({ state: "ok" });
      if (r.status === 400 && ++tries < 5) return setTimeout(go, 3000); // Stripe can take a moment
      setS({ state: "err", msg: r.data.error || "Something went wrong." });
    };
    go();
  }, [order]);
  return (
    <div className="narrow">
      {s.state === "wait" && <><h1 style={{ fontSize: "2rem" }}>Confirming payment...</h1><p className="lead">This takes a few seconds.</p></>}
      {s.state === "ok" && <><h1 style={{ fontSize: "2rem" }}>Payment received</h1><p className="lead">Thank you! Your purchase is ready.</p><Link className="btn gold" href="/dashboard?tab=domains&paid=1">Go to dashboard</Link></>}
      {s.state === "err" && <><h1 style={{ fontSize: "2rem" }}>We're still checking</h1><p className="msg err">{s.msg}</p><Link className="btn" href="/dashboard?tab=billing">See my orders</Link></>}
    </div>
  );
}
