"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import SearchForm from "./SearchForm";
import { api } from "@/lib/client";
import { usePrefs } from "./Prefs";


export default function DomainSearch() {
  const q = useSearchParams().get("q") || "";
  const { t, fmt } = usePrefs();
  const [state, setState] = useState({ loading: false, results: [], error: "", mode: "" });
  useEffect(() => {
    if (!q) return;
    setState({ loading: true, results: [], error: "", mode: "" });
    api(`/api/domains/check?q=${encodeURIComponent(q)}`).then((r) =>
      setState(r.ok ? { loading: false, results: r.data.results, error: "", mode: r.data.mode } : { loading: false, results: [], error: r.data.error || "Search failed.", mode: "" }));
  }, [q]);
  return (
    <div className="wrap page">
      <h1>Find your domain</h1>
      <p className="lead">Type a name, or a full domain like <code>mybrand.in</code>.</p>
      <SearchForm initial={q} />
      <div className="card" style={{ marginTop: 24 }}>
        {!q && <p className="note">Search above to see availability and prices.</p>}
        {state.loading && <p className="note">{t("search.checking")}</p>}
        {state.error && <p className="msg err">{state.error}</p>}
        {state.results.length > 0 && (
          <ul className="res">
            {state.results.map((r) => (
              <li key={r.domain}>
                <span className="name">{r.domain}</span>
                <span className={`st ${r.status}`}>{t(`search.${r.status}`)}</span>
                {r.status === "available" && <span className="cost">{fmt(r.price)}<small>/yr</small></span>}
                {r.status === "available" && <Link className="btn sm gold" href={`/checkout?domain=${r.domain}`}>{t("search.buy")}</Link>}
              </li>
            ))}
          </ul>
        )}
        {state.mode === "mock" && <p className="note">Test mode: availability comes from public RDAP data and purchases are simulated.</p>}
      </div>
    </div>
  );
}
