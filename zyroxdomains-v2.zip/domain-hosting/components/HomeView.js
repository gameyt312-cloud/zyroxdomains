"use client";
import SearchForm from "./SearchForm";
import PlanCards from "./PlanCards";
import { usePrefs } from "./Prefs";
import { TLDS, ROOT } from "@/lib/config";

export default function HomeView() {
  const { t, fmt } = usePrefs();
  return (
    <>
      <section className="hero">
        <div className="wrap">
          <h1>{t("hero.title")}</h1>
          <p>{t("hero.sub", { root: ROOT })}</p>
          <SearchForm />
          <div className="tldrow">{["in", "com", "co.in", "xyz", "online", "org"].map((x) => <span key={x}>.{x} <b>{fmt(TLDS[x])}</b></span>)}</div>
        </div>
      </section>
      <section className="sec">
        <div className="wrap">
          <h2>{t("free.title")}</h2>
          <p className="lead">{t("free.text")}</p>
          <div className="steps"><div><b>{t("step1")}</b></div><div><b>{t("step2")}</b><code>yourname.{ROOT}</code></div><div><b>{t("step3")}</b>10 = 10</div></div>
        </div>
      </section>
      <section className="sec white">
        <div className="wrap">
          <div className="feat">
            <div><h3>Real domains</h3><p>.in, .com, .xyz and more, checked with the registrar before you pay.</p></div>
            <div><h3>DNS you control</h3><p>A, AAAA, CNAME, TXT and MX records for every domain you buy.</p></div>
            <div><h3>Pay in your currency</h3><p>26 currencies. UPI in India, cards and wallets worldwide.</p></div>
            <div><h3>Refund if it fails</h3><p>If a registration fails after payment, the money goes back automatically.</p></div>
          </div>
        </div>
      </section>
      <section className="sec">
        <div className="wrap"><h2>{t("plans.title")}</h2><p className="lead" />
          <PlanCards /></div>
      </section>
    </>
  );
}
