"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client";
import { LANGS } from "@/lib/messages";
import { usePrefs } from "./Prefs";

export default function Nav() {
  const [user, setUser] = useState(undefined);
  const router = useRouter();
  const { t, lang, setLang, cur, setCur, currencies } = usePrefs();
  useEffect(() => { api("/api/auth/me").then((r) => setUser(r.data.user || null)); }, []);
  async function logout() {
    await api("/api/auth/logout", { method: "POST" });
    setUser(null); router.push("/"); router.refresh();
  }
  const sel = { width: "auto", padding: "6px 8px", fontSize: ".85rem" };
  return (
    <header className="nav">
      <div className="wrap">
        <Link href="/" className="logo"><b>Z</b>yroxDomains</Link>
        <nav className="links">
          <Link href="/domains">{t("nav.domains")}</Link>
          <Link href="/pricing">{t("nav.plans")}</Link>
          {user && <Link href="/dashboard">{t("nav.dashboard")}</Link>}
          {user?.admin && <Link href="/admin">Admin</Link>}
        </nav>
        <div className="right">
          <select style={sel} value={lang} onChange={(e) => setLang(e.target.value)} aria-label="Language">{LANGS.map((l) => <option key={l.code} value={l.code}>{l.name}</option>)}</select>
          <select style={sel} value={cur} onChange={(e) => setCur(e.target.value)} aria-label="Currency">{currencies.map((c) => <option key={c}>{c}</option>)}</select>
          {user === undefined ? null : user ? (
            <>
              <Link href="/dashboard?tab=credits" className="pill">{user.credits} {t("nav.credits")}</Link>
              <button className="btn ghost sm" onClick={logout}>{t("nav.logout")}</button>
            </>
          ) : (
            <>
              <Link href="/login" className="btn ghost sm">{t("nav.login")}</Link>
              <Link href="/signup" className="btn sm">{t("nav.signup")}</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
