"use client";
import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client";

const box = { width: "100%", border: "1.5px solid var(--line)", borderRadius: 10, padding: 10, font: "inherit" };

// base = "/api/my-domains/<id>" or "/api/subdomains/<id>"
export default function DomainManage({ base, isDomain, onChanged }) {
  const [st, setSt] = useState(null);
  const [mode, setMode] = useState("page"); // page | forward
  const [f, setF] = useState({ title: "", tagline: "", button_text: "", button_url: "", accent: "#4f46e5", forward_to: "", forward_type: 302 });
  const [gh, setGh] = useState("");
  const [msg, setMsg] = useState(null);
  const [code, setCode] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const r = await api(base);
    if (!r.ok) return setMsg({ t: "err", m: r.data.error || "Could not load." });
    setSt(r.data);
    const s = r.data.settings;
    setMode(s.forward_to ? "forward" : "page");
    setF({ title: s.site.title || "", tagline: s.site.tagline || "", button_text: s.site.button_text || "", button_url: s.site.button_url || "", accent: s.site.accent || "#4f46e5", forward_to: s.forward_to || "", forward_type: s.forward_type || 302 });
  }, [base]);
  useEffect(() => { load(); }, [load]);

  async function save(e) {
    e.preventDefault(); setMsg(null); setBusy(true);
    const settings = { forward_to: mode === "forward" ? f.forward_to : "", forward_type: f.forward_type, site: { title: f.title, tagline: f.tagline, button_text: f.button_text, button_url: f.button_url, accent: f.accent } };
    const r = await api(base, { method: "PUT", body: { settings } });
    setBusy(false);
    setMsg(r.ok ? { t: "ok", m: mode === "forward" ? "Saved. Visitors are now forwarded." : "Saved. Your page is updated." } : { t: "err", m: r.data.error });
    if (r.ok) load();
  }
  async function preset(p, arg) {
    setMsg(null); setBusy(true);
    const r = await api(`${base}/dns/preset`, { method: "POST", body: { preset: p, arg } });
    setBusy(false);
    setMsg(r.ok ? { t: "ok", m: "Done. DNS changes can take a few minutes." } : { t: "err", m: r.data.error });
    load(); onChanged?.();
  }
  async function resetSub() {
    setMsg(null); setBusy(true);
    const r = await api(base, { method: "PATCH", body: { type: "CNAME", target: "cname.vercel-dns.com" } });
    setBusy(false);
    setMsg(r.ok ? { t: "ok", m: "Back on the free ZyroxDomains page." } : { t: "err", m: r.data.error });
    load(); onChanged?.();
  }
  async function lock(v) {
    setMsg(null);
    const r = await api(base, { method: "PUT", body: { locked: v } });
    if (!r.ok) setMsg({ t: "err", m: r.data.error }); else { setCode(null); load(); }
  }
  async function getCode() {
    setMsg(null);
    const r = await api(`${base}/auth-code`, { method: "POST" });
    r.ok ? setCode(r.data.code) : setMsg({ t: "err", m: r.data.error });
  }

  if (!st) return <p className="note">{msg ? msg.m : "Loading..."}</p>;
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--line)" }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginBottom: 10 }}>
        <span className={`badge ${st.live ? "" : "warn"}`}>{st.live ? "Live" : "Setting up"}</span>
        {st.zone === "pending" && <span className="note" style={{ margin: 0 }}>Waiting for nameservers to update (usually minutes, sometimes a few hours).</span>}
        {!st.live && st.zone !== "pending" && <span className="note" style={{ margin: 0 }}>DNS is not answering yet. This is normal for the first few minutes.</span>}
        <button type="button" className="btn ghost sm" onClick={load}>Check again</button>
        {st.live && <a className="btn ghost sm" href={`https://${st.host}`} target="_blank" rel="noopener noreferrer">Open site</a>}
      </div>
      {st.setupError && (
        <p className="msg err">Automatic setup hit a problem: {st.setupError} {isDomain && <button type="button" className="btn sm" disabled={busy} onClick={() => preset("zyrox")}>Retry setup</button>}</p>
      )}

      <h3 style={{ fontSize: "1rem", margin: "6px 0" }}>What visitors see</h3>
      <div style={{ display: "flex", gap: 14, marginBottom: 10, flexWrap: "wrap" }}>
        <label><input type="radio" checked={mode === "page"} onChange={() => setMode("page")} /> Free landing page</label>
        <label><input type="radio" checked={mode === "forward"} onChange={() => setMode("forward")} /> Forward to another website</label>
      </div>
      <form onSubmit={save}>
        {mode === "page" ? (
          <>
            <div className="grid2">
              <div className="field"><label>Title</label><input maxLength={60} value={f.title} onChange={set("title")} placeholder={st.host} /></div>
              <div className="field"><label>Colour</label><input type="color" value={f.accent} onChange={set("accent")} style={{ height: 44, padding: 4 }} /></div>
            </div>
            <div className="field"><label>Short text</label><input maxLength={200} value={f.tagline} onChange={set("tagline")} placeholder="Something about your site" /></div>
            <div className="grid2">
              <div className="field"><label>Button text (optional)</label><input maxLength={30} value={f.button_text} onChange={set("button_text")} placeholder="Contact me" /></div>
              <div className="field"><label>Button link</label><input value={f.button_url} onChange={set("button_url")} placeholder="https://wa.me/..." /></div>
            </div>
          </>
        ) : (
          <div className="grid2">
            <div className="field"><label>Forward to</label><input required value={f.forward_to} onChange={set("forward_to")} placeholder="https://my-site.vercel.app" /></div>
            <div className="field"><label>Type</label><select value={f.forward_type} onChange={(e) => setF({ ...f, forward_type: Number(e.target.value) })}><option value={302}>Temporary (302)</option><option value={301}>Permanent (301)</option></select></div>
          </div>
        )}
        <button className="btn sm" disabled={busy}>Save</button>
      </form>

      {isDomain ? (
        <>
          <h3 style={{ fontSize: "1rem", margin: "16px 0 6px" }}>Quick DNS setup</h3>
          <p className="note" style={{ marginTop: 0 }}>Already built a site elsewhere? One click replaces the old web records.</p>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <button type="button" className="btn ghost sm" disabled={busy} onClick={() => confirm("Use the free ZyroxDomains page again?") && preset("zyrox")}>ZyroxDomains page</button>
            <input style={{ ...box, width: 150, padding: 7 }} placeholder="GitHub username" value={gh} onChange={(e) => setGh(e.target.value)} />
            <button type="button" className="btn ghost sm" disabled={busy || !gh} onClick={() => preset("github", gh)}>GitHub Pages</button>
            <button type="button" className="btn ghost sm" disabled={busy} onClick={() => confirm("Replace this domain's mail records with Google Workspace?") && preset("google")}>Google email</button>
          </div>

          <h3 style={{ fontSize: "1rem", margin: "16px 0 6px" }}>Security</h3>
          <label><input type="checkbox" checked={st.locked} onChange={(e) => lock(e.target.checked)} /> Transfer lock (stops others moving your domain away)</label>
          <div style={{ marginTop: 8 }}>
            <button type="button" className="btn ghost sm" disabled={st.locked} onClick={getCode}>Get transfer code</button>
            {st.locked && <span className="note"> Unlock first.</span>}
            {code && <p className="msg ok">Transfer code: <code style={{ userSelect: "all" }}>{code}</code></p>}
          </div>
        </>
      ) : (
        !st.usingPlatform && <p className="note">This subdomain points to your own host. <button type="button" className="btn ghost sm" disabled={busy} onClick={resetSub}>Use the free page instead</button></p>
      )}
      {msg && <p className={`msg ${msg.t}`}>{msg.m}</p>}
    </div>
  );
}
