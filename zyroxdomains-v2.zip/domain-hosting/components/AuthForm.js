"use client";
import Link from "next/link";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "@/lib/client";
import { usePrefs } from "./Prefs";

export default function AuthForm({ mode }) {
  const signup = mode === "signup";
  const { t } = usePrefs();
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const next = useSearchParams().get("next") || "/dashboard";
  async function submit(e) {
    e.preventDefault(); setBusy(true); setErr("");
    const r = await api(`/api/auth/${mode}`, { method: "POST", body: f });
    setBusy(false);
    if (!r.ok) return setErr(r.data.error || "Something went wrong.");
    window.location.href = next.startsWith("/") ? next : "/dashboard";
  }
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <div className="narrow">
      <h1 style={{ fontSize: "2rem", marginBottom: 20 }}>{signup ? t("auth.signup.title") : t("auth.login.title")}</h1>
      <form className="card" onSubmit={submit}>
        {signup && <div className="field"><label htmlFor="n">{t("auth.name")}</label><input id="n" value={f.name} onChange={set("name")} autoComplete="name" /></div>}
        <div className="field"><label htmlFor="e">{t("auth.email")}</label><input id="e" type="email" required value={f.email} onChange={set("email")} autoComplete="email" /></div>
        <div className="field"><label htmlFor="p">{t("auth.password")}</label><input id="p" type="password" required minLength={8} value={f.password} onChange={set("password")} autoComplete={signup ? "new-password" : "current-password"} /></div>
        <button className="btn" style={{ width: "100%" }} disabled={busy}>{busy ? t("auth.wait") : signup ? t("auth.signup") : t("auth.login")}</button>
        {err && <p className="msg err">{err}</p>}
      </form>
      <p className="note">{signup ? <>Already have an account? <Link href="/login">Log in</Link></> : <>New here? <Link href="/signup">Create an account</Link></>}</p>
    </div>
  );
}
