"use client";
import { useEffect, useState } from "react";
import { api, inr } from "@/lib/client";

export default function Admin() {
  const [d, setD] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => { api("/api/admin/stats").then((r) => (r.ok ? setD(r.data) : setErr(r.data.error))); }, []);
  if (err) return <div className="wrap page"><p className="msg err">{err}</p></div>;
  if (!d) return <div className="wrap page"><p className="note">Loading...</p></div>;
  return (
    <div className="wrap page">
      <h1>Admin</h1>
      <p className="lead">Revenue is paid out by Razorpay to the bank account on your Razorpay account.</p>
      <div className="stats">
        <div className="card stat"><b>{inr(d.revenue)}</b><span>Revenue ({d.paidOrders} paid orders)</span></div>
        <div className="card stat"><b>{d.users}</b><span>Users</span></div>
        <div className="card stat"><b>{d.domains}</b><span>Domains sold</span></div>
        <div className="card stat"><b>{d.subdomains}</b><span>Subdomains</span></div>
      </div>
      <div className="card scroll">
        <table><thead><tr><th>Date</th><th>User</th><th>Item</th><th>Amount</th><th>Status</th></tr></thead><tbody>
          {d.orders.map((o) => <tr key={o.id}><td>{new Date(o.created_at).toLocaleString("en-IN")}</td><td>{o.email}</td><td>{o.item}</td><td>{inr(o.amount)}</td><td>{o.status}{o.error ? `: ${o.error}` : ""}</td></tr>)}
        </tbody></table>
      </div>
    </div>
  );
}
