import { db, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
export async function GET() {
  const u = await getUser();
  if (!u) return needLogin();
  const r = await db(`orders?user_id=eq.${q(u.id)}&select=id,kind,item,amount,charge_amount,currency,status,error,created_at&order=created_at.desc&limit=50`);
  return json({ items: (r.data || []).map((o) => ({ ...o, item: o.kind === "domain" ? o.item.domain : `${o.item.plan} plan (${o.item.period})` })) });
}
