import crypto from "node:crypto";
import { db, q } from "@/lib/db";
import { getUser, needLogin, json, limited } from "@/lib/auth";
import { AD_SECONDS, AD_DAILY_CAP } from "@/lib/config";

export async function POST() {
  const user = await getUser();
  if (!user) return needLogin();
  if (limited(`ad:${user.id}`, 6, 60e3)) return json({ error: "Too fast. Wait a moment." }, 429);
  const since = new Date(Date.now() - 864e5).toISOString();
  const done = await db(`ad_views?user_id=eq.${q(user.id)}&completed_at=gte.${q(since)}&select=nonce`);
  const today = (done.data || []).length;
  if (today >= AD_DAILY_CAP) return json({ error: `Daily limit reached (${AD_DAILY_CAP} ads). Come back tomorrow.` }, 429);
  // Only one open ad per user: starting a new one voids any older unfinished one.
  await db(`ad_views?user_id=eq.${q(user.id)}&completed_at=is.null`, { method: "DELETE" });
  const nonce = crypto.randomBytes(16).toString("hex");
  const ins = await db("ad_views", { method: "POST", body: { nonce, user_id: user.id } });
  if (!ins.ok) return json({ error: "Could not start the ad." }, 502);
  return json({ nonce, seconds: AD_SECONDS, today, cap: AD_DAILY_CAP });
}
