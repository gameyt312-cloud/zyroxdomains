import { rpc } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { AD_SECONDS, AD_DAILY_CAP } from "@/lib/config";

export async function POST(req) {
  const user = await getUser();
  if (!user) return needLogin();
  const b = await req.json().catch(() => ({}));
  const r = await rpc("grant_ad_credit", { p_user: user.id, p_nonce: String(b.nonce || ""), p_secs: Math.max(1, AD_SECONDS - 1), p_cap: AD_DAILY_CAP });
  if (!r.ok) {
    const s = JSON.stringify(r.data);
    if (s.includes("DAILY_CAP")) return json({ error: "Daily limit reached." }, 429);
    return json({ error: "Ad not completed. Watch the full ad to earn a credit." }, 400);
  }
  return json({ ok: true, credits: r.data });
}
