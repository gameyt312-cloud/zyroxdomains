import { db } from "@/lib/db";
import { getUser, isAdmin, json, needLogin } from "@/lib/auth";

export async function GET() {
  const user = await getUser();
  if (!user) return needLogin();
  if (!isAdmin(user)) return json({ error: "Not allowed." }, 403);
  const [users, orders, subs, doms] = await Promise.all([
    db("users?select=id"),
    db("orders?select=id,kind,item,amount,status,error,provider,provider_payment_id,created_at,users(email)&order=created_at.desc&limit=100"),
    db("subdomains?select=id"),
    db("domains?select=id"),
  ]);
  const list = orders.data || [];
  const paid = list.filter((o) => o.status === "fulfilled");
  return json({
    users: (users.data || []).length, subdomains: (subs.data || []).length, domains: (doms.data || []).length,
    revenue: paid.reduce((a, o) => a + o.amount, 0), paidOrders: paid.length,
    orders: list.map((o) => ({ ...o, email: o.users?.email, users: undefined, item: o.kind === "domain" ? o.item.domain : `${o.item.plan}/${o.item.period}` })),
  });
}
