import { getUser, json, isAdmin } from "@/lib/auth";
import { activePlan } from "@/lib/config";
export async function GET() {
  const u = await getUser();
  if (!u) return json({ user: null });
  return json({ user: { email: u.email, name: u.name, credits: u.credits, plan: activePlan(u), planExpiresAt: u.plan_expires_at, profile: u.profile, admin: isAdmin(u) } });
}
