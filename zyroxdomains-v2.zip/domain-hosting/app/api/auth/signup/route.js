import { db, dbConfigured } from "@/lib/db";
import { hashPassword, sessionCookie, json, limited, ipOf } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function POST(req) {
  if (!dbConfigured()) return json({ error: "Server is not configured yet." }, 503);
  if (limited(`signup:${ipOf(req)}`, 8, 3600e3)) return json({ error: "Too many sign-ups. Try again later." }, 429);
  const b = await req.json().catch(() => ({}));
  const email = String(b.email || "").trim().toLowerCase();
  const name = String(b.name || "").trim().slice(0, 80);
  const password = String(b.password || "");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return json({ error: "Enter a valid email address." }, 400);
  if (password.length < 8) return json({ error: "Password must be at least 8 characters." }, 400);
  const r = await db("users", { method: "POST", body: { email, name, password_hash: hashPassword(password) } });
  if (r.status === 409) return json({ error: "An account with this email already exists." }, 409);
  if (!r.ok) return json({ error: "Could not create your account." }, 502);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(sessionCookie(r.data[0].id));
  return res;
}
