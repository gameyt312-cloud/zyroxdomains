import { db, q } from "@/lib/db";
import { verifyPassword, sessionCookie, json, limited, ipOf } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function POST(req) {
  if (limited(`login:${ipOf(req)}`, 15, 600e3)) return json({ error: "Too many attempts. Wait a few minutes." }, 429);
  const b = await req.json().catch(() => ({}));
  const email = String(b.email || "").trim().toLowerCase();
  const r = await db(`users?email=eq.${q(email)}&select=id,password_hash`);
  const u = r.data?.[0];
  if (!u || !verifyPassword(String(b.password || ""), u.password_hash)) return json({ error: "Wrong email or password." }, 401);
  const res = NextResponse.json({ ok: true });
  res.cookies.set(sessionCookie(u.id));
  return res;
}
