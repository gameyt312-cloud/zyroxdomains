import { NextResponse } from "next/server";
import { getRates } from "@/lib/rates";
export async function GET() {
  return NextResponse.json({ rates: await getRates() }, { headers: { "cache-control": "public, s-maxage=3600" } });
}
