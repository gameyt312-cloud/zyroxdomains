import { db, q } from "@/lib/db";
import { getUser, needLogin, json, limited } from "@/lib/auth";
import { PLANS, TLDS, activePlan, domainPrice } from "@/lib/config";
import { CURRENCIES, toMinor } from "@/lib/currency";
import { getRate } from "@/lib/rates";
import { isAvailable } from "@/lib/registrar";
import { createProviderOrder, paymentsReady, providerFor } from "@/lib/payments";

const LABEL = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
const PROFILE_FIELDS = ["name", "phone", "address", "city", "state", "zip", "country"];

export async function POST(req) {
  const user = await getUser();
  if (!user) return needLogin();
  if (!paymentsReady()) return json({ error: "Payments are not configured yet." }, 503);
  if (limited(`checkout:${user.id}`, 20, 600e3)) return json({ error: "Slow down a little." }, 429);

  const b = await req.json().catch(() => ({}));
  const currency = CURRENCIES[b.currency] !== undefined ? b.currency : "INR";
  let amount, item, description;

  if (b.kind === "plan") {
    const plan = PLANS[b.plan];
    const period = b.period === "year" ? "year" : "month";
    if (!plan || b.plan === "free") return json({ error: "Pick a paid plan." }, 400);
    amount = plan[period];
    item = { plan: b.plan, period };
    description = `${plan.name} plan (${period === "year" ? "1 year" : "1 month"})`;
  } else if (b.kind === "domain") {
    const domain = String(b.domain || "").toLowerCase().trim();
    const [label, ...rest] = domain.split(".");
    const tld = rest.join(".");
    const years = Math.min(5, Math.max(1, parseInt(b.years, 10) || 1));
    if (!LABEL.test(label || "") || !TLDS[tld]) return json({ error: "That domain can't be bought here." }, 400);
    const profile = Object.fromEntries(PROFILE_FIELDS.map((f) => [f, String(b.profile?.[f] || "").trim().slice(0, 120)]));
    if (PROFILE_FIELDS.some((f) => !profile[f])) return json({ error: "Fill in all contact details (domain registration requires them)." }, 400);
    profile.country = profile.country.toUpperCase().slice(0, 2);
    if (!/^[A-Z]{2}$/.test(profile.country)) return json({ error: "Country must be a 2-letter code, like IN or US." }, 400);
    if (!/^\d{4,14}$/.test(profile.phone)) return json({ error: "Phone: digits only, without the + or country code." }, 400);
    if (!(await isAvailable(domain))) return json({ error: `${domain} is no longer available.` }, 409);
    amount = domainPrice(tld, years, activePlan(user));
    item = { domain, years, profile };
    description = `${domain} (${years} year${years > 1 ? "s" : ""})`;
    await db(`users?id=eq.${q(user.id)}`, { method: "PATCH", body: { profile } });
  } else {
    return json({ error: "Bad request." }, 400);
  }

  const provider = providerFor(currency);
  if (!provider) return json({ error: `Payments in ${currency} aren't enabled yet. Choose INR or another currency.` }, 400);
  const chargeAmount = toMinor(amount, currency, currency === "INR" ? 1 : await getRate(currency));

  const ins = await db("orders", { method: "POST", body: { user_id: user.id, kind: b.kind, item, amount, currency, charge_amount: chargeAmount, provider } });
  if (!ins.ok) return json({ error: "Could not start checkout." }, 502);
  const order = ins.data[0];
  try {
    const po = await createProviderOrder({ provider, amount: chargeAmount, currency, orderId: order.id, description, email: user.email });
    await db(`orders?id=eq.${q(order.id)}`, { method: "PATCH", body: { provider_order_id: po.id } });
    return json({ orderId: order.id, provider, providerOrderId: po.id, keyId: po.keyId, url: po.url, chargeAmount, currency, description, email: user.email, name: user.name });
  } catch (e) {
    await db(`orders?id=eq.${q(order.id)}`, { method: "PATCH", body: { status: "failed", error: e.message } });
    return json({ error: e.message }, 502);
  }
}
