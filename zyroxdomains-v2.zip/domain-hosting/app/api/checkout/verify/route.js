import { db, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { confirmStripe, fulfillOrder, verifyRazorpaySignature } from "@/lib/payments";

export async function POST(req) {
  const user = await getUser();
  if (!user) return needLogin();
  const b = await req.json().catch(() => ({}));
  const r = await db(`orders?id=eq.${q(String(b.orderId || ""))}&user_id=eq.${q(user.id)}&select=*`);
  const order = r.data?.[0];
  if (!order) return json({ error: "Order not found." }, 404);

  let paymentId = null;
  try {
    if (order.provider === "stripe") paymentId = await confirmStripe(order);
    else if (verifyRazorpaySignature(order.provider_order_id, String(b.paymentId || ""), b.signature)) paymentId = String(b.paymentId);
  } catch { /* falls through to the error below */ }
  if (!paymentId) return json({ error: "Payment could not be verified yet. If you were charged, it will be applied automatically within a few minutes." }, 400);

  const out = await fulfillOrder(order.id, paymentId);
  return json(out, out.status === "failed" ? 502 : 200);
}
