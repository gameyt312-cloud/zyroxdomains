import { db, q } from "@/lib/db";
import { json } from "@/lib/auth";
import { confirmStripe, fulfillOrder, verifyStripeWebhook } from "@/lib/payments";

// Stripe Dashboard -> Developers -> Webhooks -> https://www.zyroxdomains.in/api/webhooks/stripe
// Events: checkout.session.completed, checkout.session.async_payment_succeeded
export async function POST(req) {
  const raw = await req.text();
  if (!verifyStripeWebhook(raw, req.headers.get("stripe-signature"))) return json({ error: "Bad signature." }, 400);
  const evt = JSON.parse(raw);
  if (!["checkout.session.completed", "checkout.session.async_payment_succeeded"].includes(evt.type)) return json({ ok: true });
  const sid = evt.data?.object?.id;
  const order = (await db(`orders?provider_order_id=eq.${q(sid)}&select=*`)).data?.[0];
  if (!order) return json({ ok: true });
  const paymentId = await confirmStripe(order).catch(() => null); // re-checks the session with Stripe itself
  if (paymentId) await fulfillOrder(order.id, paymentId);
  return json({ ok: true });
}
