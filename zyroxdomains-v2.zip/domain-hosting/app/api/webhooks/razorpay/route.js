import { db, q } from "@/lib/db";
import { json } from "@/lib/auth";
import { fulfillOrder, verifyRazorpayWebhook } from "@/lib/payments";

// Backup in case the buyer closes the tab after paying.
// Razorpay Dashboard -> Webhooks -> https://www.zyroxdomains.in/api/webhooks/razorpay (payment.captured, order.paid)
export async function POST(req) {
  const raw = await req.text();
  if (!verifyRazorpayWebhook(raw, req.headers.get("x-razorpay-signature"))) return json({ error: "Bad signature." }, 400);
  const evt = JSON.parse(raw);
  const pay = evt?.payload?.payment?.entity;
  if (!["payment.captured", "order.paid"].includes(evt.event) || !pay?.order_id) return json({ ok: true });
  const order = (await db(`orders?provider_order_id=eq.${q(pay.order_id)}&select=id,charge_amount,amount`)).data?.[0];
  if (!order || (order.charge_amount ?? order.amount) !== pay.amount) return json({ ok: true });
  await fulfillOrder(order.id, pay.id);
  return json({ ok: true });
}
