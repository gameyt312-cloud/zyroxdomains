import { db, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { setNameservers } from "@/lib/registrar";

const HOST = /^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/;

export async function GET() {
  const user = await getUser();
  if (!user) return needLogin();
  const r = await db(`domains?owner_id=eq.${q(user.id)}&select=id,domain,years,nameservers,zone_id,expires_at,created_at&order=created_at.desc`);
  return json({ items: (r.data || []).map(({ zone_id, ...d }) => ({ ...d, hasDns: Boolean(zone_id) })) });
}

// PATCH { id, nameservers } for domains whose DNS is hosted elsewhere
export async function PATCH(req) {
  const user = await getUser();
  if (!user) return needLogin();
  const b = await req.json().catch(() => ({}));
  const ns = (Array.isArray(b.nameservers) ? b.nameservers : []).map((x) => String(x).trim().toLowerCase()).filter(Boolean);
  if (ns.length < 2 || ns.length > 5 || !ns.every((n) => HOST.test(n))) return json({ error: "Enter 2 to 5 valid nameservers." }, 400);
  const d = (await db(`domains?id=eq.${q(String(b.id || ""))}&owner_id=eq.${q(user.id)}&select=id,registrar_order_id,zone_id`)).data?.[0];
  if (!d) return json({ error: "Not found." }, 404);
  if (d.zone_id) return json({ error: "DNS for this domain is managed here. Edit its records instead." }, 400);
  try { await setNameservers(d.registrar_order_id, ns); } catch (e) { return json({ error: e.message }, 502); }
  await db(`domains?id=eq.${q(d.id)}`, { method: "PATCH", body: { nameservers: ns } });
  return json({ ok: true });
}
