import { db, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { cleanSettings } from "@/lib/sites";
import { resolveHost } from "@/lib/dnscheck";
import { zoneStatus } from "@/lib/cloudflare";
import { setLock } from "@/lib/registrar";
import { PLATFORM_A } from "@/lib/config";

const COLS = "id,domain,zone_id,registrar_order_id,forward_to,forward_type,site,locked,setup_error";
const mine = async (id, user) => (await db(`domains?id=eq.${q(id)}&owner_id=eq.${q(user.id)}&select=${COLS}`)).data?.[0];

// Live status + current website settings
export async function GET(_req, { params }) {
  const user = await getUser(); if (!user) return needLogin();
  const d = await mine((await params).id, user);
  if (!d) return json({ error: "Not found." }, 404);
  const zone = d.zone_id ? await zoneStatus(d.zone_id) : null;
  const dns = await resolveHost(d.domain);
  return json({
    host: d.domain,
    live: dns.ips.length > 0,
    usingPlatform: dns.ips.includes(PLATFORM_A),
    ips: dns.ips,
    zone: zone?.status || null,
    setupError: d.setup_error,
    locked: d.locked,
    settings: { forward_to: d.forward_to || "", forward_type: d.forward_type, site: d.site || {} },
  });
}

// Save landing page / forwarding / transfer lock
export async function PUT(req, { params }) {
  const user = await getUser(); if (!user) return needLogin();
  const d = await mine((await params).id, user);
  if (!d) return json({ error: "Not found." }, 404);
  const b = await req.json().catch(() => ({}));
  const patch = {};
  if (b.settings) {
    const c = cleanSettings(b.settings, [d.domain]);
    if (c.error) return json({ error: c.error }, 400);
    Object.assign(patch, c);
  }
  if (typeof b.locked === "boolean" && b.locked !== d.locked) {
    try { await setLock(d.registrar_order_id, b.locked); } catch (e) { return json({ error: `Registrar: ${e.message}` }, 502); }
    patch.locked = b.locked;
  }
  if (!Object.keys(patch).length) return json({ error: "Nothing to save." }, 400);
  const r = await db(`domains?id=eq.${q(d.id)}`, { method: "PATCH", body: patch });
  return r.ok ? json({ ok: true }) : json({ error: "Could not save." }, 502);
}
