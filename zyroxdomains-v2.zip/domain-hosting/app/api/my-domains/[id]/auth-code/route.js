import { db, q } from "@/lib/db";
import { getUser, needLogin, json, limited } from "@/lib/auth";
import { getAuthCode } from "@/lib/registrar";

// Transfer-out code. Only while the domain is unlocked, and rate limited.
export async function POST(_req, { params }) {
  const user = await getUser(); if (!user) return needLogin();
  if (limited(`epp:${user.id}`, 5, 3600e3)) return json({ error: "Too many requests. Try again later." }, 429);
  const { id } = await params;
  const d = (await db(`domains?id=eq.${q(id)}&owner_id=eq.${q(user.id)}&select=registrar_order_id,locked`)).data?.[0];
  if (!d) return json({ error: "Not found." }, 404);
  if (d.locked) return json({ error: "Turn off the transfer lock first." }, 400);
  try { return json({ ok: true, ...(await getAuthCode(d.registrar_order_id)) }); }
  catch (e) { return json({ error: e.message }, 502); }
}
