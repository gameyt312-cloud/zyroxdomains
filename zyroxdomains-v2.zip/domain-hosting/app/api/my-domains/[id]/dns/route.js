import { db, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { listZoneRecords, addZoneRecord, deleteZoneRecord } from "@/lib/cloudflare";
import { IPV4, HOST } from "@/lib/subdomain";
import { removeDomain } from "@/lib/vercel";
import { PLATFORM_A, PLATFORM_CNAME } from "@/lib/config";

const TYPES = ["A", "AAAA", "CNAME", "TXT", "MX"];
const IPV6 = /^[0-9a-f:]{2,39}$/i;
const NAME = /^(@|[a-z0-9*_]([a-z0-9_.-]{0,100}[a-z0-9_])?)$/i;

async function owned(id, user) {
  const d = (await db(`domains?id=eq.${q(id)}&owner_id=eq.${q(user.id)}&select=domain,zone_id`)).data?.[0];
  return d?.zone_id ? d : null;
}

export async function GET(_req, { params }) {
  const user = await getUser(); if (!user) return needLogin();
  const d = await owned((await params).id, user);
  if (!d) return json({ error: "DNS isn't managed here for this domain." }, 404);
  const r = await listZoneRecords(d.zone_id);
  return r.error ? json({ error: r.error }, 502) : json({ domain: d.domain, records: r.records.filter((x) => TYPES.includes(x.type)) });
}

export async function POST(req, { params }) {
  const user = await getUser(); if (!user) return needLogin();
  const d = await owned((await params).id, user);
  if (!d) return json({ error: "Not found." }, 404);
  const b = await req.json().catch(() => ({}));
  const type = String(b.type || "").toUpperCase();
  const name = String(b.name || "@").trim().toLowerCase();
  const content = String(b.content || "").trim();
  if (!TYPES.includes(type)) return json({ error: "Type must be A, AAAA, CNAME, TXT or MX." }, 400);
  if (!NAME.test(name)) return json({ error: "Name can be @ or a label like www or blog." }, 400);
  if (type === "A" && !(IPV4.test(content) && !/^(10\.|127\.|0\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(content))) return json({ error: "Enter a public IPv4 address." }, 400);
  if (type === "AAAA" && !(IPV6.test(content) && content.includes(":"))) return json({ error: "Enter a valid IPv6 address." }, 400);
  if ((type === "CNAME" || type === "MX") && !HOST.test(content)) return json({ error: "Enter a hostname like mail.example.com." }, 400);
  if (type === "TXT" && (!content || content.length > 500 || /[\u0000-\u001f]/.test(content))) return json({ error: "TXT value must be 1-500 characters." }, 400);
  const rec = { type, name: name === "@" ? d.domain : name.endsWith(`.${d.domain}`) || name === d.domain ? name : `${name}.${d.domain}`, content };
  if (type === "MX") rec.priority = Math.min(65535, Math.max(0, parseInt(b.priority, 10) || 10));
  const r = await addZoneRecord(d.zone_id, rec);
  if (r.error) return json({ error: r.error }, 502);
  // Pointing the website somewhere else: let go of the domain on our Vercel project so the new host can claim it.
  const web = ["A", "AAAA", "CNAME"].includes(type) && (name === "@" || name === "www" || rec.name === d.domain || rec.name === `www.${d.domain}`);
  if (web && content !== PLATFORM_A && content !== PLATFORM_CNAME) { await removeDomain(d.domain); await removeDomain(`www.${d.domain}`); }
  return json({ ok: true });
}

export async function DELETE(req, { params }) {
  const user = await getUser(); if (!user) return needLogin();
  const d = await owned((await params).id, user);
  if (!d) return json({ error: "Not found." }, 404);
  const rid = new URL(req.url).searchParams.get("rid") || "";
  if (!/^[a-f0-9]{32}$/.test(rid)) return json({ error: "Bad record id." }, 400);
  const r = await deleteZoneRecord(d.zone_id, rid);
  return r.error ? json({ error: r.error }, 502) : json({ ok: true });
}
