import { db, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { applyPreset, PRESETS } from "@/lib/provision";

// POST { preset: "zyrox" | "github" | "google", arg? }  also used by "Retry setup"
export async function POST(req, { params }) {
  const user = await getUser(); if (!user) return needLogin();
  const { id } = await params;
  const d = (await db(`domains?id=eq.${q(id)}&owner_id=eq.${q(user.id)}&select=id,domain,zone_id`)).data?.[0];
  if (!d?.zone_id) return json({ error: "DNS isn't managed here for this domain." }, 404);
  const b = await req.json().catch(() => ({}));
  if (!PRESETS[b.preset]) return json({ error: "Unknown setup." }, 400);
  const r = await applyPreset({ domain: d.domain, zoneId: d.zone_id, preset: b.preset, arg: String(b.arg || "").trim() });
  if (r.error) return json({ error: r.error }, 502);
  if (b.preset === "zyrox") await db(`domains?id=eq.${q(d.id)}`, { method: "PATCH", body: { setup_error: null } });
  return json({ ok: true });
}
