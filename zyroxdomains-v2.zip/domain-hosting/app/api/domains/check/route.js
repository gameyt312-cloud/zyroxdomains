import { json, getUser } from "@/lib/auth";
import { searchDomains, registrarMode } from "@/lib/registrar";
import { TLDS, DEFAULT_TLDS, activePlan, domainPrice } from "@/lib/config";

const LABEL = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;

export async function GET(request) {
  const qs = (new URL(request.url).searchParams.get("q") || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "");
  if (!qs) return json({ error: "Type a name to search." }, 400);

  let label = qs, tlds = DEFAULT_TLDS;
  if (qs.includes(".")) {
    const i = qs.indexOf(".");
    label = qs.slice(0, i);
    const tld = qs.slice(i + 1);
    if (!TLDS[tld]) return json({ error: `We don't sell .${tld} yet. Try one of: ${Object.keys(TLDS).map((t) => "." + t).join(", ")}` }, 400);
    tlds = [tld, ...DEFAULT_TLDS.filter((t) => t !== tld)].slice(0, 8);
  }
  if (!LABEL.test(label)) return json({ error: "Use letters, numbers and hyphens only." }, 400);

  const user = await getUser();
  const plan = activePlan(user);
  const found = await searchDomains(label, tlds);
  return json({
    mode: registrarMode(),
    results: found.map((r) => ({ ...r, price: domainPrice(r.tld, 1, plan) })),
  });
}
