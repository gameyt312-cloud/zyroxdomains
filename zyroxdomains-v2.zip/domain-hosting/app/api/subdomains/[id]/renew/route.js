import { db, rpc, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { PLANS, RENEW_CREDITS, activePlan } from "@/lib/config";
import { createRecord } from "@/lib/cloudflare";

const ERR = {
  NO_CREDITS: [402, `You need ${RENEW_CREDITS} credits. Watch ${RENEW_CREDITS} ads to earn them.`],
  TOO_EARLY: [409, "Renewal opens 7 days before expiry."],
  NOT_FOUND: [404, "Not found."],
};

export async function POST(_req, { params }) {
  const user = await getUser();
  if (!user) return needLogin();
  const { id } = await params;
  const plan = PLANS[activePlan(user)];
  const r = await rpc("renew_subdomain", { p_user: user.id, p_sub: Number(id), p_cost: plan.freeRenew ? 0 : RENEW_CREDITS, p_days: plan.days });
  if (!r.ok) {
    const code = Object.keys(ERR).find((k) => JSON.stringify(r.data).includes(k));
    return code ? json({ error: ERR[code][1] }, ERR[code][0]) : json({ error: "Renewal failed." }, 502);
  }
  // If DNS was switched off at expiry, switch it back on.
  const s = (await db(`subdomains?id=eq.${q(id)}&select=name,target,record_type,cf_record_id`)).data?.[0];
  if (s && !s.cf_record_id) {
    const c = await createRecord(s.name, s.record_type, s.target);
    if (c.id) await db(`subdomains?id=eq.${q(id)}`, { method: "PATCH", body: { cf_record_id: c.id } });
  }
  return json({ ok: true, expires_at: r.data });
}
