import { db, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { createRecord, updateRecord, deleteRecord } from "@/lib/cloudflare";
import { validateTarget } from "@/lib/subdomain";
import { cleanSettings } from "@/lib/sites";
import { resolveHost } from "@/lib/dnscheck";
import { addDomain, removeDomain } from "@/lib/vercel";
import { ROOT, PLATFORM_CNAME } from "@/lib/config";

async function mine(id, user) {
  const r = await db(`subdomains?id=eq.${q(id)}&owner_id=eq.${q(user.id)}&select=*`);
  return r.data?.[0];
}

// Live status + current website settings
export async function GET(_req, { params }) {
  const user = await getUser();
  if (!user) return needLogin();
  const s = await mine((await params).id, user);
  if (!s) return json({ error: "Not found." }, 404);
  const host = `${s.name}.${ROOT}`;
  const dns = await resolveHost(host);
  return json({
    host, live: dns.ips.length > 0, usingPlatform: s.target === PLATFORM_CNAME, ips: dns.ips,
    settings: { forward_to: s.forward_to || "", forward_type: s.forward_type, site: s.site || {} },
  });
}

// Save landing page / forwarding
export async function PUT(req, { params }) {
  const user = await getUser();
  if (!user) return needLogin();
  const s = await mine((await params).id, user);
  if (!s) return json({ error: "Not found." }, 404);
  if (new Date(s.expires_at) < new Date()) return json({ error: "This subdomain has expired. Renew it first." }, 403);
  const b = await req.json().catch(() => ({}));
  const c = cleanSettings(b.settings || {}, [`${s.name}.${ROOT}`]);
  if (c.error) return json({ error: c.error }, 400);
  const r = await db(`subdomains?id=eq.${q(s.id)}`, { method: "PATCH", body: c });
  return r.ok ? json({ ok: true }) : json({ error: "Could not save." }, 502);
}

export async function PATCH(req, { params }) {
  const user = await getUser();
  if (!user) return needLogin();
  const { id } = await params;
  const s = await mine(id, user);
  if (!s) return json({ error: "Not found." }, 404);
  if (new Date(s.expires_at) < new Date()) return json({ error: "This subdomain has expired. Renew it first." }, 403);
  const b = await req.json().catch(() => ({}));
  const type = b.type === "A" ? "A" : "CNAME";
  const target = String(b.target || "").trim().toLowerCase();
  const bad = validateTarget(type, target);
  if (bad) return json({ error: bad }, 400);

  let recordId = s.cf_record_id;
  if (recordId && type !== s.record_type) {
    // Cloudflare can't change a record's type in place reliably: replace it.
    await deleteRecord(recordId);
    const c = await createRecord(s.name, type, target);
    if (c.error) return json({ error: `DNS failed: ${c.error}` }, 502);
    recordId = c.id || null;
  } else {
    const u = await updateRecord(recordId, s.name, type, target);
    if (u.error) return json({ error: `DNS failed: ${u.error}` }, 502);
  }
  // Our Vercel project only hosts the subdomain while it points at our platform.
  const host = `${s.name}.${ROOT}`;
  const v = target === PLATFORM_CNAME ? await addDomain(host) : await removeDomain(host);
  if (v.error && target === PLATFORM_CNAME) return json({ error: `HTTPS setup failed: ${v.error}` }, 502);
  await db(`subdomains?id=eq.${q(id)}`, { method: "PATCH", body: { target, record_type: type, cf_record_id: recordId } });
  return json({ ok: true });
}

export async function DELETE(_req, { params }) {
  const user = await getUser();
  if (!user) return needLogin();
  const { id } = await params;
  const s = await mine(id, user);
  if (!s) return json({ error: "Not found." }, 404);
  const d = await deleteRecord(s.cf_record_id);
  if (d.error) return json({ error: `DNS failed: ${d.error}` }, 502);
  await removeDomain(`${s.name}.${ROOT}`);
  await db(`subdomains?id=eq.${q(id)}`, { method: "DELETE" });
  return json({ ok: true });
}
