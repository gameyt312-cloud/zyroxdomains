import { db, dbConfigured, q } from "@/lib/db";
import { getUser, needLogin, json } from "@/lib/auth";
import { PLANS, ROOT, PLATFORM_CNAME, activePlan } from "@/lib/config";
import { addDomain } from "@/lib/vercel";
import { createRecord, deleteRecord, dnsConfigured } from "@/lib/cloudflare";
import { NAME, RESERVED, validateTarget } from "@/lib/subdomain";

// GET /api/subdomains            -> my subdomains + limits (login required)
// GET /api/subdomains?name=foo   -> { available } (public)
export async function GET(request) {
  if (!dbConfigured()) return json({ error: "Server is not configured yet." }, 503);
  const name = new URL(request.url).searchParams.get("name");
  if (name !== null) {
    const n = name.trim().toLowerCase();
    if (!NAME.test(n) || RESERVED.has(n)) return json({ available: false, reason: "invalid" });
    const r = await db(`subdomains?name=eq.${q(n)}&select=name`);
    return r.ok ? json({ available: r.data.length === 0 }) : json({ error: "Lookup failed." }, 502);
  }
  const user = await getUser();
  if (!user) return needLogin();
  const plan = activePlan(user);
  const r = await db(`subdomains?owner_id=eq.${q(user.id)}&select=id,name,target,record_type,expires_at,cf_record_id,created_at&order=created_at.desc`);
  return json({
    root: ROOT, plan, limit: PLANS[plan].subdomains, freeRenew: PLANS[plan].freeRenew, dns: dnsConfigured(),
    items: (r.data || []).map(({ cf_record_id, ...s }) => ({ ...s, live: Boolean(cf_record_id) })),
  });
}

// POST { name, target, type }
export async function POST(request) {
  if (!dbConfigured()) return json({ error: "Server is not configured yet." }, 503);
  const user = await getUser();
  if (!user) return needLogin();
  const b = await request.json().catch(() => ({}));
  const name = String(b.name || "").trim().toLowerCase();
  // Default: no setup needed. The subdomain points at our platform and shows the free landing page.
  const platform = b.type === "PLATFORM" || !String(b.target || "").trim();
  const target = platform ? PLATFORM_CNAME : String(b.target).trim().toLowerCase();
  const type = platform ? "CNAME" : b.type === "A" ? "A" : "CNAME";

  if (!NAME.test(name) || RESERVED.has(name)) return json({ error: "Name must be 3-30 characters: letters, numbers, hyphens. Some names are reserved." }, 400);
  const bad = validateTarget(type, target);
  if (bad) return json({ error: bad }, 400);

  const plan = activePlan(user);
  const mine = await db(`subdomains?owner_id=eq.${q(user.id)}&select=id`);
  if ((mine.data || []).length >= PLANS[plan].subdomains) {
    return json({ error: `Your ${PLANS[plan].name} plan allows ${PLANS[plan].subdomains} subdomain${PLANS[plan].subdomains > 1 ? "s" : ""}. Upgrade for more.` }, 403);
  }

  const expires_at = new Date(Date.now() + PLANS[plan].days * 864e5).toISOString();
  const ins = await db("subdomains", { method: "POST", body: { name, target, record_type: type, owner_id: user.id, expires_at } });
  if (ins.status === 409) return json({ error: "That name is already taken." }, 409);
  if (!ins.ok) return json({ error: "Could not save your subdomain." }, 502);

  const dns = await createRecord(name, type, target);
  if (dns.error) {
    await db(`subdomains?name=eq.${q(name)}`, { method: "DELETE" });
    return json({ error: `DNS failed: ${dns.error}` }, 502);
  }
  if (dns.id) await db(`subdomains?name=eq.${q(name)}`, { method: "PATCH", body: { cf_record_id: dns.id } });
  if (platform) {
    const v = await addDomain(`${name}.${ROOT}`);
    if (v.error) {
      await deleteRecord(dns.id);
      await db(`subdomains?name=eq.${q(name)}`, { method: "DELETE" });
      return json({ error: `HTTPS setup failed: ${v.error}` }, 502);
    }
  }
  return json({ ok: true, hostname: `${name}.${ROOT}`, dnsCreated: Boolean(dns.ok), expires_at, platform });
}
