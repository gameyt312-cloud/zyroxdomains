import { db, q } from "@/lib/db";
import { json } from "@/lib/auth";
import { deleteRecord } from "@/lib/cloudflare";
import { removeDomain } from "@/lib/vercel";
import { ROOT } from "@/lib/config";

// Daily (see vercel.json). Expired -> DNS switched off. 7 days later -> name released.
export async function GET(req) {
  const secret = process.env.CRON_SECRET;
  if (!secret || req.headers.get("authorization") !== `Bearer ${secret}`) return json({ error: "Unauthorized." }, 401);
  const now = new Date().toISOString();
  const grace = new Date(Date.now() - 7 * 864e5).toISOString();

  const off = (await db(`subdomains?expires_at=lt.${q(now)}&cf_record_id=not.is.null&select=id,name,cf_record_id`)).data || [];
  for (const s of off) {
    const d = await deleteRecord(s.cf_record_id);
    if (!d.error) { await removeDomain(`${s.name}.${ROOT}`); await db(`subdomains?id=eq.${s.id}`, { method: "PATCH", body: { cf_record_id: null } }); }
  }
  const gone = await db(`subdomains?expires_at=lt.${q(grace)}`, { method: "DELETE" });
  return json({ switchedOff: off.length, released: gone.data?.length || 0 });
}
