import { NextResponse } from "next/server";
import { db, dbConfigured } from "@/lib/db";
import { razorpayReady, stripeReady, mockMode } from "@/lib/payments";
import { registrarMode } from "@/lib/registrar";
import { dnsConfigured, zonesConfigured } from "@/lib/cloudflare";
import { vercelConfigured } from "@/lib/vercel";

// Open https://www.zyroxdomains.in/api/health to see what is still missing. Never shows secret values.
export async function GET() {
  const database = dbConfigured() ? (await db("users?select=id&limit=1")).ok : false;
  const checks = {
    database,
    sessionSecret: (process.env.SESSION_SECRET || "").length >= 16,
    cronSecret: Boolean(process.env.CRON_SECRET),
    cloudflareSubdomains: dnsConfigured(),
    cloudflareBoughtDomains: zonesConfigured(),
    vercelAutoHttps: vercelConfigured(),
    registrar: registrarMode(),
    razorpay: razorpayReady(),
    stripe: stripeReady(),
    mockPayments: mockMode(),
    googleRewardedAds: Boolean(process.env.NEXT_PUBLIC_GPT_REWARDED_UNIT),
    adsTxt: Boolean(process.env.ADSENSE_PUB_ID),
  };
  return NextResponse.json({ ok: checks.database && checks.sessionSecret, checks });
}
