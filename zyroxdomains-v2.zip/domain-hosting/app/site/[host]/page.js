import { redirect, permanentRedirect } from "next/navigation";
import { db, dbConfigured, q } from "@/lib/db";
import { ROOT, OWNER_EMAIL } from "@/lib/config";
import { cleanUrl } from "@/lib/sites";

export const dynamic = "force-dynamic";

async function lookup(host) {
  if (!dbConfigured()) return null;
  const cols = "forward_to,forward_type,site";
  if (host.endsWith(`.${ROOT}`)) {
    const name = host.slice(0, -(ROOT.length + 1));
    if (name.includes(".")) return null;
    const r = await db(`subdomains?name=eq.${q(name)}&select=${cols},expires_at`);
    const s = r.data?.[0];
    return s ? { ...s, expired: new Date(s.expires_at) < new Date() } : null;
  }
  const bare = host.replace(/^www\./, "");
  const r = await db(`domains?domain=eq.${q(bare)}&select=${cols}`);
  return r.data?.[0] || null;
}

export async function generateMetadata({ params }) {
  const host = decodeURIComponent((await params).host).toLowerCase();
  const rec = await lookup(host);
  return { title: rec?.site?.title || host, robots: { index: false } };
}

export default async function SitePage({ params }) {
  const host = decodeURIComponent((await params).host).toLowerCase();
  const rec = await lookup(host);

  // URL forwarding (301 permanent / 302 temporary). redirect() must run outside try/catch.
  if (rec && !rec.expired && rec.forward_to && cleanUrl(rec.forward_to)) {
    if (rec.forward_type === 301) permanentRedirect(rec.forward_to); else redirect(rec.forward_to);
  }

  const s = rec?.site || {};
  const accent = /^#[0-9a-f]{6}$/i.test(s.accent || "") ? s.accent : "#4f46e5";
  const link = cleanUrl(s.button_url);
  let title, text;
  if (!rec) { title = "This domain isn't connected yet"; text = "The address is pointing here, but no account has claimed it."; }
  else if (rec.expired) { title = "This subdomain has expired"; text = "Its owner needs to renew it to bring it back."; }
  else { title = s.title || host; text = s.tagline || "This website is coming soon."; }

  return (
    <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24, textAlign: "center", background: `linear-gradient(160deg, ${accent}14, #ffffff 55%)` }}>
      <div style={{ maxWidth: 560 }}>
        <div style={{ width: 64, height: 64, borderRadius: 18, background: accent, margin: "0 auto 22px", display: "grid", placeItems: "center", color: "#fff", fontWeight: 800, fontSize: 28 }}>
          {(s.title || host).charAt(0).toUpperCase()}
        </div>
        <h1 style={{ fontSize: "clamp(1.8rem, 5vw, 2.8rem)", lineHeight: 1.15, margin: "0 0 12px", wordBreak: "break-word" }}>{title}</h1>
        <p style={{ fontSize: "1.1rem", color: "#4b5563", margin: "0 0 26px" }}>{text}</p>
        {rec && !rec.expired && link && s.button_text && (
          <a href={link} rel="noopener noreferrer nofollow" style={{ display: "inline-block", background: accent, color: "#fff", padding: "13px 26px", borderRadius: 12, fontWeight: 700, textDecoration: "none" }}>{s.button_text}</a>
        )}
        <p style={{ marginTop: 48, fontSize: ".85rem", color: "#9ca3af" }}>
          Powered by <a href={`https://${ROOT}`} style={{ color: "inherit" }}>ZyroxDomains</a> · <a href={`mailto:${OWNER_EMAIL}?subject=Report%20${encodeURIComponent(host)}`} style={{ color: "inherit" }}>Report abuse</a>
        </p>
      </div>
    </main>
  );
}
