// Google requires /ads.txt on your domain before it pays out. Set ADSENSE_PUB_ID=pub-XXXXXXXXXXXXXXXX
export async function GET() {
  const pub = process.env.ADSENSE_PUB_ID;
  if (!pub) return new Response("Not configured", { status: 404 });
  return new Response(`google.com, ${pub}, DIRECT, f08c47fec0942fa0\n`, { headers: { "content-type": "text/plain" } });
}
