import "./globals.css";
import { Bricolage_Grotesque, DM_Sans } from "next/font/google";

const head = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-head", weight: ["600", "800"] });
const body = DM_Sans({ subsets: ["latin"], variable: "--font-body" });
const site = process.env.NEXT_PUBLIC_SITE_URL || "https://www.zyroxdomains.in";

export const metadata = {
  metadataBase: new URL(site),
  title: { default: "ZyroxDomains: domains, free subdomains and hosting plans", template: "%s | ZyroxDomains" },
  description: "Search and buy domains, get a free subdomain, and your domain goes live automatically.",
};

// Minimal on purpose: customer domains (/site/*) share this layout but must NOT show our nav, footer or ads.
export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${head.variable} ${body.variable}`}>
      <body>{children}</body>
    </html>
  );
}
