import { Suspense } from "react";
import CheckoutSuccess from "@/components/CheckoutSuccess";
export const metadata = { title: "Payment" };
export default function Page() { return <Suspense><CheckoutSuccess /></Suspense>; }
