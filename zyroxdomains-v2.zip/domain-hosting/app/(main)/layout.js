import Script from "next/script";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import Prefs from "@/components/Prefs";

// Our own site only: nav, footer, language/currency, and the Google ad scripts.
export default function MainLayout({ children }) {
  const adsense = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;
  return (
    <>
      {adsense && <Script async strategy="afterInteractive" crossOrigin="anonymous" src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adsense}`} />}
      {process.env.NEXT_PUBLIC_GPT_REWARDED_UNIT && <Script async strategy="afterInteractive" src="https://securepubads.g.doubleclick.net/tag/js/gpt.js" />}
      <Prefs>
        <Nav />
        {children}
        <Footer />
      </Prefs>
    </>
  );
}
