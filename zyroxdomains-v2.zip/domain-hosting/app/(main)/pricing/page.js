import PlanCards from "@/components/PlanCards";
export const metadata = { title: "Plans" };
export default function Pricing() {
  return (
    <div className="wrap page">
      <h1>Simple plans</h1>
      <p className="lead">Start free. Upgrade for more subdomains, longer validity, and renewals without ads. Cancel any time by not renewing.</p>
      <PlanCards />
      <p className="note">Plans cover the features of this platform (subdomains, DNS, renewals, domain discounts). They don't include server hosting; point your subdomain at any host you like.</p>
    </div>
  );
}
