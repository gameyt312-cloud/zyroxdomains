import { notFound } from "next/navigation";
const P = {
  terms: ["Terms of service", [
    ["Service", "ZyroxDomains lets you search and buy domain names, claim free subdomains, and subscribe to plans that raise subdomain limits and validity. Plans do not include server hosting."],
    ["Free subdomains", "A free subdomain is valid for 30 days. Renew it with 10 credits, earned by watching ads. Expired subdomains stop resolving and are released 7 days later."],
    ["Acceptable use", "No phishing, malware, spam, illegal content or abuse. We may suspend any subdomain that breaks these rules."],
    ["Domain purchases", "Domains are registered through our registrar partner. You must give accurate contact details; false details can lead to suspension by the registry."],
  ]],
  privacy: ["Privacy policy", [
    ["What we store", "Your name, email, a hashed password, the domains and subdomains you create, and the contact details you enter for domain registration."],
    ["Payments", "Card, UPI and bank details are handled by Razorpay. We never see or store them."],
    ["Advertising", "Ad providers may use cookies to show ads. You can avoid ads by subscribing to a paid plan."],
    ["Your data", "Email zyroxop443@gmail.com to ask for your data to be exported or deleted."],
  ]],
  refunds: ["Refund policy", [
    ["Failed registrations", "If we take payment but cannot register your domain, the payment is refunded automatically to the original payment method."],
    ["Domains", "Once a domain is registered it cannot be refunded, as the registry fee is non-refundable."],
    ["Plans", "Plans can be refunded within 3 days of purchase if you haven't used the added limits. Email zyroxop443@gmail.com."],
  ]],
  contact: ["Contact", [
    ["Support", "Email zyroxop443@gmail.com. We reply within two working days."],
    ["Website", "www.zyroxdomains.in"],
  ]],
};
export async function generateMetadata({ params }) { const { slug } = await params; return { title: P[slug]?.[0] }; }
export default async function Legal({ params }) {
  const { slug } = await params;
  if (!P[slug]) notFound();
  return (
    <div className="wrap page legal">
      <h1>{P[slug][0]}</h1>
      {P[slug][1].map(([h, t]) => <section key={h}><h2>{h}</h2><p>{t}</p></section>)}
    </div>
  );
}
