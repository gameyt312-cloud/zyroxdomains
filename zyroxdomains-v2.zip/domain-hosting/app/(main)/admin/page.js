import Admin from "@/components/Admin";
export const metadata = { title: "Admin" };
export default function Page() { return <Admin />; }
