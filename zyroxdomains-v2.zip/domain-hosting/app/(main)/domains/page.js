import { Suspense } from "react";
import DomainSearch from "@/components/DomainSearch";
export const metadata = { title: "Search domains" };
export default function Page() { return <Suspense><DomainSearch /></Suspense>; }
